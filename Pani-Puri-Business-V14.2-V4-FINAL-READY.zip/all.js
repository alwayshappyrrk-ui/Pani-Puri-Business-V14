
// V13 stability + migration helpers
function v92El(id){return document.getElementById(id)}
function normalizeV142State(){if(!state||typeof state!=='object')state={entries:[],newCustomers:0,repeatCustomers:0,expense:0,expenses:[],creditLedger:[],deletedEntries:[]};if(!Array.isArray(state.entries))state.entries=[];if(!Array.isArray(state.expenses))state.expenses=[];if(!Array.isArray(state.creditLedger))state.creditLedger=[];if(!Array.isArray(state.deletedEntries))state.deletedEntries=[];}
function v92SyncStatus(){
  normalizeV142State(); const n=(state&&Array.isArray(state.entries))?state.entries.length:0;
  const a=v92El('savedCount'), b=v92El('entryStatus');
  if(a)a.textContent=n;
  if(b)b.textContent='Saved Entries: '+n+' • Local data active';
}
function v92Migrate(){
  // Carry forward data from earlier app versions when available.
  const keys=['PP_V81_STATE','PP_V82_STATE','PP_V8_STATE','PP_V81_MENU','PP_V82_MENU','PP_V8_MENU','PP_V81_PRICES','PP_V82_PRICES','PP_V8_PRICES','PP_V81_NOTE','PP_V82_NOTE','PP_V8_NOTE'];
  try{
    if(!state || !Array.isArray(state.entries) || state.entries.length===0){
      for(const k of ['PP_V81_STATE','PP_V82_STATE','PP_V8_STATE']){
        const raw=localStorage.getItem(k); if(!raw) continue;
        const old=JSON.parse(raw); if(old && Array.isArray(old.entries) && old.entries.length){state=old;save(STATE_KEY,state);break}
      }
    }
    if(!menuItems || !menuItems.length){
      for(const k of ['PP_V81_MENU','PP_V82_MENU','PP_V8_MENU']){
        const raw=localStorage.getItem(k); if(!raw) continue;
        const old=JSON.parse(raw); if(Array.isArray(old)&&old.length){menuItems=old;save(MENU_KEY,menuItems);break}
      }
    }
    if(!state.newCustomers)state.newCustomers=0;
    if(!state.repeatCustomers)state.repeatCustomers=0;
    if(!state.expense)state.expense=0; if(!Array.isArray(state.expenses))state.expenses=[]; if(!Array.isArray(state.creditLedger))state.creditLedger=[];if(!Array.isArray(state.deletedEntries))state.deletedEntries=[];
    state.entries.forEach(e=>{if(!e.isoDate){let d=entryDate(e);if(d&&!isNaN(d))e.isoDate=localDateKey(d);e.localDate=e.isoDate}});
    save(STATE_KEY,state);
  }catch(e){}
}
function v92SaveEverything(){
  try{save(STATE_KEY,state);save(MENU_KEY,menuItems);save(PRICES_KEY,prices);localStorage.setItem(NOTE_KEY,localStorage.getItem(NOTE_KEY)||'')}catch(e){}
  if(typeof v9Save==='function')v9Save();
  v92SyncStatus();
}


const STATE_KEY='PP_V81_STATE', MENU_KEY='PP_V81_MENU', PRICES_KEY='PP_V81_PRICES', NOTE_KEY='PP_V81_NOTE', PIN_KEY='PP_V81_PIN', PIN_HASH_KEY='PP_V114_PIN_HASH', BILL_KEY='PP_V142_CURRENT_BILL';
const DEFAULT_MENU=[
{id:'pani',name:'Panipuri',emoji:'🥣',price:20,active:true},
{id:'shev',name:'Shevpuri',emoji:'🫓',price:30,active:true},
{id:'dahi',name:'Dahipuri',emoji:'🥛',price:30,active:true},
{id:'bhalf',name:'Bhel Half',emoji:'🥗',price:25,active:true},
{id:'bfull',name:'Bhel Full',emoji:'🥗',price:40,active:true}
];
let menuItems=load(MENU_KEY,DEFAULT_MENU);
let prices=load(PRICES_KEY,{pani:20,shev:30,dahi:30,bhelHalf:25,bhelFull:40});
let state=load(STATE_KEY,{entries:[],newCustomers:0,repeatCustomers:0,expense:0,expenses:[],creditLedger:[],deletedEntries:[]});
if(!Array.isArray(state.expenses))state.expenses=[]; if(!Array.isArray(state.creditLedger))state.creditLedger=[];if(!Array.isArray(state.deletedEntries))state.deletedEntries=[];
let bill=load(BILL_KEY,[]),period='daily'; if(!Array.isArray(bill))bill=[];

const days=['रविवार','सोमवार','मंगळवार','बुधवार','गुरुवार','शुक्रवार','शनिवार'];
function load(k,d){try{let x=localStorage.getItem(k);return x?JSON.parse(x):JSON.parse(JSON.stringify(d))}catch(e){return JSON.parse(JSON.stringify(d))}}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function money(n){return '₹'+Number(n||0).toLocaleString('en-IN')}
function today(){return new Date()}
// Local calendar date key used for Daily Summary and saved entries.
// This deliberately uses local time (not UTC) so entries near midnight stay on the correct business day.
function localDateKey(d){
 let x=d instanceof Date?d:new Date(d);if(isNaN(x))return '';
 let y=x.getFullYear(),m=String(x.getMonth()+1).padStart(2,'0'),dd=String(x.getDate()).padStart(2,'0');
 return y+'-'+m+'-'+dd;
}
function day(){return days[today().getDay()]}
function date(){return today().toLocaleDateString('mr-IN',{day:'2-digit',month:'2-digit',year:'numeric'})}
function time(){return today().toLocaleTimeString('mr-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}
function toast(t){let x=document.getElementById('toast');x.textContent=t;x.style.display='block';clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>x.style.display='none',1900)}
function clock(){marathiDay.textContent=day();clockEl.textContent=date()+' • '+time();if(!adminPage.classList.contains('hidden')){adminDay.textContent=day();adminClock.textContent=date()+' • '+time()}}
const clockEl=document.getElementById('clock');setInterval(clock,1000);

function esc(s){return String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
function color(i){let c=['#2563eb','#f59e0b','#db2777','#16a34a','#7c3aed','#0891b2','#ea580c','#4f46e5'];let n=[...String(i)].reduce((a,b)=>a+b.charCodeAt(0),0);return c[n%c.length]}
function renderMainMenu(){
 const g=document.getElementById('menuGrid');
 const active=menuItems.filter(x=>x.active);
 g.innerHTML=active.map(x=>`<button class="main" style="background:${color(x.id)}" onclick="addToBill('${esc(x.id)}')">${x.emoji||'🍽️'} ${esc(x.name)}<span class="price">${money(x.price)}</span></button>`).join('');
}
function saveBillDraft(){try{save(BILL_KEY,bill)}catch(e){}}
function addToBill(id){
 const m=menuItems.find(x=>x.id===id&&x.active);if(!m)return;
 let line=bill.find(x=>x.id===id);
 if(line)line.qty++;else bill.push({id:m.id,name:m.name,price:Number(m.price)||0,qty:1});
 saveBillDraft(); renderBill();
}
function renderBill(){
 let count=bill.reduce((a,x)=>a+x.qty,0),total=bill.reduce((a,x)=>a+x.qty*x.price,0);
 billCount.textContent=count+' items';billTotal.textContent=money(total);
 billLines.innerHTML=bill.length?bill.map((x,i)=>`<div class="cartline"><div style="flex:1"><b>${esc(x.name)}</b>${x.purpose?`<div class="small">कशासाठी: ${esc(x.purpose)}</div>`:''}</div><input type="number" min="1" value="${x.qty}" onchange="setBillQty(${i},this.value)"><span>${money(x.qty*x.price)}</span><button type="button" title="फक्त ही item काढा" onclick="removeBill(${i})">🗑️</button></div>`).join(''):'अजून कोणतीही Entry नाही.';
}
function setBillQty(i,q){q=Math.max(1,Number(q)||1);if(bill[i])bill[i].qty=q;saveBillDraft();renderBill()}
function removeBill(i){bill.splice(i,1);saveBillDraft();renderBill()}
function clearBill(){
 if(!bill.length){toast('चालू Bill आधीच रिकामा आहे');return}
 const ok=confirm('⚠️ चालू Bill मधील सर्व items Clear करायचे आहेत का?\n\nहा बदल Undo करता येणार नाही.\n\nYes/OK केल्यावरच Bill Clear होईल.');
 if(!ok){toast('Clear All रद्द केले');return}
 bill.length=0; saveBillDraft();
 selectedBill.textContent='';custName.value='';custMobile.value='';
 closeCustomer();
 renderBill();
 toast('✓ चालू Bill पूर्णपणे Clear झाला');
}
function finishBill(){
 if(!bill.length){toast('पहिले Menu मधून item निवडा');return}
 selectedBill.textContent=bill.map(x=>x.name+' × '+x.qty).join(' • ')+' | Total '+money(bill.reduce((a,x)=>a+x.qty*x.price,0));
 custName.value='';custMobile.value='';customerModal.classList.remove('hidden');
}
function closeCustomer(){customerModal.classList.add('hidden')}
let pendingSaleCustomer=null;
function closePayment(){paymentModal.classList.add('hidden')}
function savePayment(mode){
 try{
  normalizeV142State();
  if(!pendingSaleCustomer||!bill.length){toast('❌ चालू Bill मध्ये Entry नाही');return}
  if(mode==='Credit'&&!custName.value.trim()){toast('❌ Credit साठी Customer नाव आवश्यक आहे');paymentModal.classList.add('hidden');customerModal.classList.remove('hidden');return}
  const total=bill.reduce((a,x)=>a+(Number(x.qty)||0)*(Number(x.price)||0),0);
  if(total<=0){toast('❌ Bill Total 0 आहे');return}
  const details=bill.map(x=>x.purpose?x.name+' ('+x.purpose+') x '+x.qty:x.name+' x '+x.qty).join(' | ');
  const entry={id:Date.now()+Math.random(),isoDate:localDateKey(),localDate:localDateKey(),date:date(),time:time(),day:day(),name:bill.length===1?bill[0].name:'Multiple Items',qty:bill.reduce((a,x)=>a+(Number(x.qty)||0),0),price:bill.length===1?Number(bill[0].price)||0:0,total,customer:pendingSaleCustomer,customerName:custName.value.trim(),customerMobile:custMobile.value.trim(),order:'Single',details,paymentMode:mode,creditStatus:mode==='Credit'?'Outstanding':'Paid'};
  state.entries.push(entry);
  if(mode==='Credit')state.creditLedger.push({id:entry.id,entryId:entry.id,date:entry.date,time:entry.time,customerName:entry.customerName,customerMobile:entry.customerMobile,amount:total,paid:0,outstanding:total,status:'Outstanding',payments:[]});
  if(pendingSaleCustomer==='नवीन')state.newCustomers++;else state.repeatCustomers++;
  // IMPORTANT: save sale BEFORE clearing the current bill.
  save(STATE_KEY,state);
  localStorage.setItem('PP_V142_ENTRIES_MIRROR',JSON.stringify(state.entries));
  v92SaveEverything();
  localStorage.removeItem(BILL_KEY);
  bill.length=0;
  renderBill();updateQuickCreditTotal();closePayment();closeCustomer();pendingSaleCustomer=null;
  toast('✓ ENTRY SAVED\n'+money(total)+' • '+mode);
  queueDriveSync(false);
 }catch(err){
  console.error(err);
  toast('❌ Entry Save Error\n'+(err&&err.message?err.message:'Unknown error'));
 }
}
function saveSingleBill(customer){chooseCustomer(customer)}

let otherAmount='',expenseAmount='';
function openOtherAmount(){otherAmount='';otherDisplay.textContent='₹0';otherPurpose.value='';otherModal.classList.remove('hidden')}
function closeOther(){otherModal.classList.add('hidden')}
function keyOther(k){if(k==='C')otherAmount='';else if(otherAmount.length<7)otherAmount+=k;otherDisplay.textContent=money(Number(otherAmount)||0)}
function confirmOther(){let a=Number(otherAmount)||0;if(a<=0){toast('❌ Amount द्या');return}let purpose=otherPurpose.value.trim();bill.push({id:'other-'+Date.now(),name:purpose||'Other Amount',price:a,qty:1,purpose});saveBillDraft();closeOther();renderBill();toast('✓ Other Amount चालू Bill मध्ये add झाला: '+money(a))}
function openExpensePad(){expenseAmount='';expenseDisplay.textContent='₹0';expensePurpose.value='';expensePadModal.classList.remove('hidden')}
function closeExpensePad(){expensePadModal.classList.add('hidden')}
function keyExpense(k){if(k==='C')expenseAmount='';else if(expenseAmount.length<7)expenseAmount+=k;expenseDisplay.textContent=money(Number(expenseAmount)||0)}
function confirmExpense(){
 let a=Number(expenseAmount)||0;
 if(a<=0){toast('❌ Expense amount द्या');return}
 if(!Array.isArray(state.expenses))state.expenses=[];
 const item={id:'exp-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),date:date(),time:time(),day:day(),isoDate:localDateKey(),amount:a,purpose:expensePurpose.value.trim()};
 state.expenses.push(item);
 state.expense=state.expenses.reduce((x,e)=>x+Number(e.amount||0),0);
 save(STATE_KEY,state);
 localStorage.setItem('PP_V142_EXPENSES_MIRROR',JSON.stringify(state.expenses));
 try{v92SaveEverything()}catch(e){}
 closeExpensePad();
 expenseAmount='';
 toast('✓ EXPENSE SAVED\n'+money(a));
 if(typeof renderAdmin==='function') renderAdmin();
 queueDriveSync(false);
}
let adIndex=0,adTimer=null;
function getAdItems(){try{let a=JSON.parse(localStorage.getItem('PP_AD_ITEMS')||'[]');return Array.isArray(a)?a:[]}catch(e){return []}}
function saveAdItems(a){localStorage.setItem('PP_AD_ITEMS',JSON.stringify(a))}
function pickAdvertisement(){if(typeof AndroidMedia!=='undefined'&&AndroidMedia.pickAdvertisementMedia)AndroidMedia.pickAdvertisementMedia();else toast('❌ Android media picker उपलब्ध नाही')}
function removeAdvertisement(){if(typeof AndroidMedia!=='undefined'&&AndroidMedia.removeAdvertisement)AndroidMedia.removeAdvertisement();else{localStorage.removeItem('PP_AD_ITEMS');updateAdAdminStatus();toast('✓ Ads removed')}}
window.__adMediaResult=function(raw){try{let r=typeof raw==='string'?JSON.parse(raw):raw;if(!r||!r.ok){toast('❌ '+(r?.message||'Advertisement error'));return}if(r.message==='removed'){localStorage.removeItem('PP_AD_ITEMS');adIndex=0;updateAdAdminStatus();toast('✓ All advertisements removed');return}let d=typeof r.message==='string'?JSON.parse(r.message):r.message;let items=(d.items||[]).map((x,i)=>({type:x.type,url:x.url,duration:Number(x.duration)||5}));if(!items.length&&d.url)items=[{type:d.type,url:d.url,duration:5}];saveAdItems(items);adIndex=0;updateAdAdminStatus();toast('✓ '+items.length+' advertisement(s) saved');resetIdleAd()}catch(e){toast('❌ Advertisement result error')}};
function updateAdAdminStatus(){let items=getAdItems(),el=document.getElementById('adAdminStatus'),ed=document.getElementById('adTimerEditor');if(el)el.textContent=items.length?('✓ '+items.length+' media ready • Main Screen idle 10 sec नंतर Full Screen'): 'Advertisement सेट केलेली नाही.';if(ed)ed.innerHTML=items.length?items.map((x,i)=>`<div class="credit-card"><b>${i+1}. ${x.type==='video'?'🎥 Video':'🖼️ Image'}</b><div class="small" style="word-break:break-all">${esc(x.url)}</div>${x.type==='image'?`<label class="small">Display time (sec)</label><input type="number" min="1" max="300" value="${Number(x.duration)||5}" onchange="setAdDuration(${i},this.value)">`:'<div class="small">Video: स्वतः loop होईल.</div>'}</div>`).join(''):' '}
function setAdDuration(i,v){let a=getAdItems();if(!a[i])return;a[i].duration=Math.max(1,Math.min(300,Number(v)||5));saveAdItems(a);resetIdleAd()}
function saveAdText(){localStorage.setItem('PP_AD_TEXT',document.getElementById('adText').value.trim());toast('✓ Ad text saved');resetIdleAd()}
function hideAdvertisement(){adFull.classList.add('hidden');if(adVideo){adVideo.pause();adVideo.removeAttribute('src');adVideo.load()}clearTimeout(adTimer);resetIdleAd()}
function showAdvertisement(){let items=getAdItems();if(!items.length||!entryPage||entryPage.classList.contains('hidden'))return;let item=items[adIndex%items.length],label=document.getElementById('adLabel'),txt=localStorage.getItem('PP_AD_TEXT')||'';label.textContent=txt;label.classList.toggle('hidden',!txt);adImage.classList.add('hidden');adVideo.classList.add('hidden');clearTimeout(adTimer);if(item.type==='video'){adVideo.src=item.url;adVideo.classList.remove('hidden');adVideo.muted=true;adVideo.loop=true;adVideo.play().catch(()=>{});adTimer=setTimeout(nextAdvertisement,Math.max(5,Number(item.duration)||10)*1000)}else{adImage.src=item.url;adImage.classList.remove('hidden');adTimer=setTimeout(nextAdvertisement,Math.max(1,Number(item.duration)||5)*1000)}adFull.classList.remove('hidden')}
function nextAdvertisement(){let items=getAdItems();if(!items.length){hideAdvertisement();return}adIndex=(adIndex+1)%items.length;showAdvertisement()}
function resetIdleAd(){clearTimeout(window.__idleAdTimer);if(!entryPage||entryPage.classList.contains('hidden'))return;window.__idleAdTimer=setTimeout(showAdvertisement,10000)}
function renderCustomers(){
 let m=customers(),arr=Object.values(m),q=(document.getElementById('customerSearch').value||'').toLowerCase();arr=arr.filter(x=>(x.name+' '+x.mobile).toLowerCase().includes(q));let top=Object.values(m).sort((a,b)=>b.total-a.total).slice(0,10);
 topCustomers.innerHTML=top.length?top.map((x,i)=>`<div class="customer"><b>#${i+1} ${esc(x.name)}</b> ${x.mobile?'• '+esc(x.mobile):''}<br>${x.orders} orders • ${money(x.total)} • Last ${x.last}</div>`).join(''):'<span class="small">नाव/मोबाईल save केलेले customer नाहीत.</span>';
 customerHistory.innerHTML=arr.length?arr.map(x=>`<div class="customer"><b>${esc(x.name)}</b> ${x.mobile?'• '+esc(x.mobile):''}<br>एकूण ${x.orders} visits • ${money(x.total)}<br><span class="small">Last: ${x.last}</span></div>`).join(''):'<span class="small">Customer सापडला नाही.</span>'
}
function creditGroups(){let groups={};(state.creditLedger||[]).forEach(x=>{let k=x.customerMobile||x.customerName||('id-'+x.id);if(!groups[k])groups[k]={key:k,name:x.customerName||'Customer',mobile:x.customerMobile||'',amount:0,items:[]};groups[k].amount+=Number(x.outstanding||0);groups[k].items.push(x)});return Object.values(groups)}
function totalOutstanding(){return creditGroups().reduce((a,g)=>a+g.amount,0)}
function updateQuickCreditTotal(){let el=document.getElementById('quickCreditTotal');if(el)el.textContent=money(totalOutstanding())}
function renderCreditList(){const el=document.getElementById('creditList');if(!el)return;let groups=creditGroups().filter(g=>g.amount>0.009);let qt=document.getElementById('quickCreditTotal');if(qt)qt.textContent=money(totalOutstanding());if(!groups.length){el.innerHTML='<span class="small">सध्या कोणतीही उधारी नाही. ✓</span>';return}el.innerHTML=groups.sort((a,b)=>b.amount-a.amount).map(g=>`<div class="credit-card"><b>👤 ${esc(g.name)}</b> ${g.mobile?'• '+esc(g.mobile):''}<div style="font-size:22px;font-weight:900;margin:5px 0">बाकी: ${money(g.amount)}</div><div class="actions"><button class="btn" onclick="openCreditDetail('${esc(g.key)}')">More / पूर्ण माहिती</button><button class="btn green" onclick="openCreditPay('${esc(g.key)}')">💵 पैसे जमा</button></div></div>`).join('')}
function openCreditQuickView(){renderCreditList();document.getElementById('quickCreditSummary').textContent='एकूण उधारी: '+money(totalOutstanding());let el=document.getElementById('quickCreditList');let groups=creditGroups().filter(g=>g.amount>0.009);el.innerHTML=groups.length?groups.sort((a,b)=>b.amount-a.amount).map(g=>`<div class="credit-card"><b>👤 ${esc(g.name)}</b> ${g.mobile?'• '+esc(g.mobile):''}<div style="font-size:24px;font-weight:900">${money(g.amount)}</div><div class="actions"><button class="btn" onclick="openCreditDetail('${esc(g.key)}')">More</button><button class="btn green" onclick="openCreditPay('${esc(g.key)}')">💵 जमा</button></div></div>`).join(''):'<span class="small">उधारी नाही.</span>';document.getElementById('creditQuickModal').classList.remove('hidden')}
function closeCreditQuickView(){document.getElementById('creditQuickModal').classList.add('hidden')}
function findCreditGroup(key){return creditGroups().find(g=>g.key===key)}
function openCreditDetail(key){let g=findCreditGroup(key);if(!g)return;let body=document.getElementById('creditDetailBody');let total=0,paid=0;let html=`<div class="selected"><b>👤 ${esc(g.name)}</b>${g.mobile?' • '+esc(g.mobile):''}<br>एकूण बाकी: <b>${money(g.amount)}</b></div>`;g.items.sort((a,b)=>String(b.date+b.time).localeCompare(String(a.date+a.time))).forEach(x=>{total+=Number(x.amount||0);paid+=Number(x.paid||0);let payments=Array.isArray(x.payments)?x.payments:[];html+=`<div class="credit-card"><b>${esc(x.date)} • ${esc(x.time)}</b><br>घेतले: <b>${money(x.amount)}</b><br>दिलेली रक्कम: <b>${money(x.paid)}</b><br>राहिले: <b>${money(x.outstanding)}</b><br><span class="small">${payments.length?'Payment history: '+payments.map(p=>esc(p.date+' '+p.time)+' • '+money(p.amount)).join(' | '):'अजून payment नाही'}</span></div>`});html+=`<div class="summary"><div class="stat">Total Taken<b>${money(total)}</b></div><div class="stat">Total Paid<b>${money(paid)}</b></div><div class="stat">Remaining<b>${money(g.amount)}</b></div></div>`;body.innerHTML=html;body.dataset.key=key;document.getElementById('creditDetailModal').classList.remove('hidden')}
function closeCreditDetail(){document.getElementById('creditDetailModal').classList.add('hidden')}
let creditPayKey=null,creditPayAmount='';function openCreditPay(key){let g=findCreditGroup(key);if(!g)return;creditPayKey=key;creditPayAmount='';document.getElementById('creditPayCustomer').textContent=g.name+' • बाकी '+money(g.amount);document.getElementById('creditPayDisplay').textContent='₹0';document.getElementById('creditPayModal').classList.remove('hidden')}
function closeCreditPay(){document.getElementById('creditPayModal').classList.add('hidden');creditPayKey=null;creditPayAmount=''}
function keyCreditPay(k){if(k==='C')creditPayAmount='';else if(creditPayAmount.length<7)creditPayAmount+=k;document.getElementById('creditPayDisplay').textContent=money(Number(creditPayAmount)||0)}
function confirmCreditPay(){let g=findCreditGroup(creditPayKey),a=Number(creditPayAmount)||0;if(!g||a<=0)return toast('❌ जमा रक्कम द्या');if(a>g.amount+0.009)return toast('❌ बाकीपेक्षा जास्त रक्कम देऊ शकत नाही');let remain=a;g.items.forEach(x=>{if(remain<=0)return;let pay=Math.min(remain,Number(x.outstanding||0));if(pay>0){x.paid=Number(x.paid||0)+pay;x.outstanding=Math.max(0,Number(x.outstanding||0)-pay);x.status=x.outstanding>0.009?'Outstanding':'Paid';if(!Array.isArray(x.payments))x.payments=[];x.payments.push({amount:pay,date:date(),time:time()});let e=state.entries.find(e=>String(e.id)===String(x.entryId));if(e)e.creditStatus=x.status;remain-=pay}});save(STATE_KEY,state);v92SaveEverything();closeCreditPay();updateQuickCreditTotal();renderAdmin();toast('✓ पैसे जमा: '+money(a));queueDriveSync(false)}

function openPin(){
 document.getElementById('pin').value='';
 document.getElementById('pinModal').classList.remove('hidden');
 setTimeout(()=>document.getElementById('pin').focus(),80);
}
function closePin(){document.getElementById('pinModal').classList.add('hidden')}
function adminPin(){return localStorage.getItem(PIN_KEY)||'2580'}
function login(){
 const entered=String(document.getElementById('pin').value||'').trim();
 if(entered!==adminPin()){toast('❌ चुकीचा Admin PIN');return}
 closePin();
 document.getElementById('entryPage').classList.add('hidden');
 document.getElementById('adminPage').classList.remove('hidden');
 renderAdmin();
 window.scrollTo(0,0);
}
function backHome(){
 document.getElementById('adminPage').classList.add('hidden');
 document.getElementById('entryPage').classList.remove('hidden');
 resetIdleAd();
 window.scrollTo(0,0);
}
function changeAdminPin(){
 const cur=String(document.getElementById('currentPin').value||'').trim();
 const np=String(document.getElementById('newPin').value||'').trim();
 const cp=String(document.getElementById('confirmPin').value||'').trim();
 if(cur!==adminPin())return toast('❌ सध्याचा PIN चुकीचा आहे');
 if(!/^\d{4,8}$/.test(np))return toast('❌ नवीन PIN 4 ते 8 अंकांचा असावा');
 if(np!==cp)return toast('❌ नवीन PIN जुळत नाही');
 localStorage.setItem(PIN_KEY,np);
 document.getElementById('currentPin').value='';document.getElementById('newPin').value='';document.getElementById('confirmPin').value='';
 toast('✓ Admin PIN बदलला');
}
function payCurrentBill(mode){
 if(!bill.length){toast('पहिले Bill मध्ये item add करा');return}
 // Cash/Credit are now chosen from the current bill. Customer screen follows only when needed.
 pendingSaleCustomer=null;
 selectedBill.textContent=bill.map(x=>x.name+' × '+x.qty).join(' • ')+' | Total '+money(bill.reduce((a,x)=>a+x.qty*x.price,0));
 custName.value='';custMobile.value='';
 customerModal.classList.remove('hidden');
 customerModal.dataset.preferredPayment=mode;
}

// =========================================================
// V14.2 FAMILY ORDER — restored without changing normal billing
// =========================================================
let familyBill=[];
let familyDraftName='';
let familyDraftMobile='';

function openFamily(){
  const modal=document.getElementById('familyModal');
  if(!modal)return;
  if(!Array.isArray(familyBill))familyBill=[];
  familyDraftName=document.getElementById('familyName')?.value||'';
  familyDraftMobile=document.getElementById('familyMobile')?.value||'';
  renderFamilyMenu();
  modal.classList.remove('hidden');
}

function renderFamilyMenu(){
  const el=document.getElementById('familyMenu');
  if(!el)return;
  if(!Array.isArray(familyBill))familyBill=[];
  const active=menuItems.filter(m=>m.active);
  el.innerHTML=active.map((m,i)=>{
    const line=familyBill.find(x=>x.id===m.id);
    const qty=line?Number(line.qty)||0:0;
    return `<div class="entry" style="align-items:center">
      <div class="entrytext"><b>${esc(m.emoji||'🍽️')} ${esc(m.name)}</b><br><span class="small">${money(m.price)} × ${qty}</span></div>
      <div style="display:flex;gap:5px;align-items:center">
        <button type="button" class="btn light" onclick="familyQty('${esc(m.id)}',-1)">−</button>
        <b style="min-width:24px;text-align:center">${qty}</b>
        <button type="button" class="btn" onclick="familyQty('${esc(m.id)}',1)">+</button>
      </div>
    </div>`;
  }).join('') || '<span class="small">Menu item नाही.</span>';
  const total=familyBill.reduce((a,x)=>a+(Number(x.qty)||0)*(Number(x.price)||0),0);
  const ft=document.getElementById('familyTotal');if(ft)ft.textContent=money(total);
  const mini=document.getElementById('familyMiniTotal');if(mini)mini.textContent=money(total);
}

function familyQty(id,delta){
  const m=menuItems.find(x=>String(x.id)===String(id)&&x.active);
  if(!m)return;
  let line=familyBill.find(x=>String(x.id)===String(id));
  if(!line && delta>0){
    line={id:m.id,name:m.name,price:Number(m.price)||0,qty:0};
    familyBill.push(line);
  }
  if(line){
    line.qty=Math.max(0,(Number(line.qty)||0)+Number(delta||0));
    if(line.qty<=0)familyBill=familyBill.filter(x=>String(x.id)!==String(id));
  }
  renderFamilyMenu();
}

function minimizeFamily(){
  const modal=document.getElementById('familyModal');
  if(!modal)return;
  familyDraftName=document.getElementById('familyName')?.value.trim()||'';
  familyDraftMobile=document.getElementById('familyMobile')?.value.trim()||'';
  if(familyBill.length){
    modal.classList.add('hidden');
    const mini=document.getElementById('familyMini');if(mini)mini.classList.remove('hidden');
    renderFamilyMenu();
    toast('✓ Family Order minimized');
  }else{
    toast('पहिले Family Order मध्ये item add करा');
  }
}

function restoreFamily(){
  const mini=document.getElementById('familyMini');if(mini)mini.classList.add('hidden');
  const modal=document.getElementById('familyModal');if(modal)modal.classList.remove('hidden');
  const n=document.getElementById('familyName');if(n)n.value=familyDraftName||'';
  const m=document.getElementById('familyMobile');if(m)m.value=familyDraftMobile||'';
  renderFamilyMenu();
}

function cancelFamily(){
  familyBill=[];
  familyDraftName='';familyDraftMobile='';
  const n=document.getElementById('familyName');if(n)n.value='';
  const m=document.getElementById('familyMobile');if(m)m.value='';
  const modal=document.getElementById('familyModal');if(modal)modal.classList.add('hidden');
  const mini=document.getElementById('familyMini');if(mini)mini.classList.add('hidden');
  renderFamilyMenu();
}

function familySave(customer){
  if(!familyBill.length){toast('❌ Family Order मध्ये item add करा');return;}
  const name=(document.getElementById('familyName')?.value||familyDraftName||'').trim();
  const mobile=(document.getElementById('familyMobile')?.value||familyDraftMobile||'').trim();
  const total=familyBill.reduce((a,x)=>a+(Number(x.qty)||0)*(Number(x.price)||0),0);
  if(total<=0){toast('❌ Family Order Total 0 आहे');return;}
  const details=familyBill.map(x=>`${x.name} x ${x.qty}`).join(' | ');
  const entry={
    id:Date.now()+Math.random(),
    isoDate:localDateKey(),localDate:localDateKey(),
    date:date(),time:time(),day:day(),
    name:'Family Order',qty:familyBill.reduce((a,x)=>a+(Number(x.qty)||0),0),
    price:0,total,customer,customerName:name,customerMobile:mobile,
    order:'Family',details,paymentMode:'Cash',creditStatus:'Paid'
  };
  state.entries.push(entry);
  if(customer==='नवीन')state.newCustomers++;else state.repeatCustomers++;
  save(STATE_KEY,state);
  v92SaveEverything();
  familyBill=[];familyDraftName='';familyDraftMobile='';
  const modal=document.getElementById('familyModal');if(modal)modal.classList.add('hidden');
  const mini=document.getElementById('familyMini');if(mini)mini.classList.add('hidden');
  renderFamilyMenu();
  renderBill();
  toast('✓ Family Order Saved\\n'+money(total));
  queueDriveSync(false);
}

function chooseCustomer(customer){
 pendingSaleCustomer=customer;
 customerModal.classList.add('hidden');
 const total=bill.reduce((a,x)=>a+x.qty*x.price,0);
 paymentSummary.textContent=(custName.value.trim()||'Customer')+' • '+money(total);
 const preferred=customerModal.dataset.preferredPayment;
 delete customerModal.dataset.preferredPayment;
 if(preferred){savePayment(preferred);return;}
 paymentModal.classList.remove('hidden');
}
function saveNote(){const v=document.getElementById('noteInput').value.trim();localStorage.setItem(NOTE_KEY,v);document.getElementById('homeNote').textContent=v||'आजची Note नाही.';toast('✓ Note saved');queueDriveSync(false)}
function setPeriod(p){period=p;['daily','weekly','monthly'].forEach(x=>{const el=document.getElementById(x==='daily'?'td':x==='weekly'?'tw':'tm');if(el)el.classList.toggle('active',x===p)});renderDashboard()}
function renderDashboard(){
 const entries=state.entries||[], now=new Date(), key=localDateKey(now);
 let filtered=entries;
 if(period==='daily')filtered=entries.filter(e=>String(e.isoDate||e.localDate||'')===key);
 else if(period==='weekly'){const d=new Date(now);const dayNo=(d.getDay()+6)%7;d.setDate(d.getDate()-dayNo);const start=d.toISOString().slice(0,10);filtered=entries.filter(e=>String(e.isoDate||e.localDate||'')>=start)}
 else {const ym=String(now.getFullYear()).padStart(4,'0')+'-'+String(now.getMonth()+1).padStart(2,'0');filtered=entries.filter(e=>String(e.isoDate||e.localDate||'').startsWith(ym))}
 const sale=filtered.reduce((a,e)=>a+Number(e.total||0),0);
 const po=document.getElementById('periodSale'),pn=document.getElementById('periodOrders');if(po)po.textContent=money(sale);if(pn)pn.textContent=String(filtered.length);
 const bs=document.getElementById('bestSeller');
 if(bs){const map={};entries.forEach(e=>{const k=e.name||e.details||'Other';map[k]=(map[k]||0)+Number(e.total||0)});const arr=Object.entries(map).sort((a,b)=>b[1]-a[1]).slice(0,5);bs.innerHTML=arr.length?arr.map(x=>`<div class="customer"><b>${esc(x[0])}</b> • ${money(x[1])}</div>`).join(''):'<span class="small">Sale data नाही.</span>'}
}
function renderMenuManager(){
 const el=document.getElementById('menuManager');if(!el)return;
 el.innerHTML=menuItems.map((m,i)=>`<div class="entry">
   <div class="entrytext">
     <b>${esc(m.emoji||'🍽️')} ${esc(m.name)}</b><br>
     <span class="small">Current Price ₹${Number(m.price)||0} • ${m.active?'Active':'Inactive'}</span>
     <div style="display:flex;gap:6px;align-items:center;margin-top:7px">
       <input id="menuPrice_${i}" type="number" min="0" step="1" value="${Number(m.price)||0}" style="margin:0;flex:1" placeholder="Price ₹">
       <button class="btn green" type="button" onclick="editMenuPrice(${i})">💾 Save Price</button>
     </div>
   </div>
   <button class="btn" type="button" onclick="toggleMenu(${i})">${m.active?'⏸️ Inactive':'▶️ Active'}</button>
 </div>`).join('');
}
function editMenuPrice(i){
 const m=menuItems[i]; if(!m)return;
 const input=document.getElementById('menuPrice_'+i);
 const price=Number(input&&input.value);
 if(!Number.isFinite(price)||price<=0)return toast('❌ योग्य Price द्या');
 m.price=price;
 save(MENU_KEY,menuItems);
 if(typeof prices==='object'&&prices)m.id&&(prices[m.id]=price);
 save(PRICES_KEY,prices);
 v92SaveEverything();
 renderMainMenu();
 renderMenuManager();
 toast('✓ '+m.name+' ची Price ₹'+price+' केली');
}
function toggleMenu(i){if(!menuItems[i])return;menuItems[i].active=!menuItems[i].active;save(MENU_KEY,menuItems);v92SaveEverything();renderMainMenu();renderMenuManager();toast('✓ Menu updated')}
function openAddMenu(){document.getElementById('addMenuModal').classList.remove('hidden')}
function closeAddMenu(){document.getElementById('addMenuModal').classList.add('hidden')}
function addMenuItem(){const name=document.getElementById('newMenuName').value.trim(),price=Number(document.getElementById('newMenuPrice').value)||0,emoji=document.getElementById('newMenuEmoji').value.trim()||'🍽️';if(!name||price<=0)return toast('❌ Item name आणि price द्या');menuItems.push({id:'custom-'+Date.now(),name,emoji,price,active:true});save(MENU_KEY,menuItems);v92SaveEverything();renderMainMenu();renderMenuManager();closeAddMenu();toast('✓ Menu item added')}
function customers(){const m={};(state.entries||[]).forEach(e=>{const name=e.customerName||'Customer',mobile=e.customerMobile||'',k=mobile||name;if(!m[k])m[k]={name,mobile,orders:0,total:0,last:e.date||''};m[k].orders++;m[k].total+=Number(e.total||0);m[k].last=(e.date||'')+' '+(e.time||'')});return m}
function restoreAdminLiveData(){
  try{
    // Keep the existing state as source of truth when it already contains data.
    // If a previous build wrote the admin mirrors, recover them without touching
    // menu, credit, bill, or other working data.
    if(!Array.isArray(state.entries))state.entries=[];
    if(state.entries.length===0){
      const mr=localStorage.getItem('PP_V142_ENTRIES_MIRROR');
      if(mr){const a=JSON.parse(mr);if(Array.isArray(a)&&a.length)state.entries=a;}
    }
    if(!Array.isArray(state.expenses))state.expenses=[];
    const er=localStorage.getItem('PP_V142_EXPENSES_MIRROR');
    if(state.expenses.length===0 && er){const a=JSON.parse(er);if(Array.isArray(a)&&a.length)state.expenses=a;}
    // Legacy V8/V81/V82 migration is intentionally limited to entries only.
    if(state.entries.length===0){
      for(const k of ['PP_V81_STATE','PP_V82_STATE','PP_V8_STATE']){
        const raw=localStorage.getItem(k);
        if(!raw)continue;
        try{const old=JSON.parse(raw);if(old&&Array.isArray(old.entries)&&old.entries.length){state.entries=old.entries;break}}catch(e){}
      }
    }
    save(STATE_KEY,state);
  }catch(e){}
}
function renderAdmin(){
 restoreAdminLiveData();
 v92SyncStatus();
 const totalEl=document.getElementById('total'),itemsEl=document.getElementById('items'),avgEl=document.getElementById('avg'),repeatPctEl=document.getElementById('repeatPct'),noteInputEl=document.getElementById('noteInput'),homeNoteEl=document.getElementById('homeNote'),entriesEl=document.getElementById('entries');
 state.entries.forEach(e=>{if(!e.isoDate){let d=entryDate(e);if(d&&!isNaN(d))e.isoDate=localDateKey(d);e.localDate=e.isoDate}});
 save(STATE_KEY,state);

 let total=state.entries.reduce((a,e)=>a+e.total,0),orders=state.entries.length,rep=state.repeatCustomers+state.newCustomers; if(!Array.isArray(state.expenses))state.expenses=[]; if(!Array.isArray(state.creditLedger))state.creditLedger=[];if(!Array.isArray(state.deletedEntries))state.deletedEntries=[];
 if(totalEl)totalEl.textContent=money(total);if(itemsEl)itemsEl.textContent=orders;if(avgEl)avgEl.textContent=money(orders?total/orders:0);if(repeatPctEl)repeatPctEl.textContent=(rep?Math.round(state.repeatCustomers/rep*100):0)+'%'; let expTotal=state.expenses.reduce((a,e)=>a+Number(e.amount||0),0); state.expense=expTotal; let exEl=document.getElementById('expenseTotal'),npEl=document.getElementById('netProfit'); if(exEl)exEl.textContent=money(expTotal); if(npEl)npEl.textContent=money(total-expTotal); renderCreditList();
 let n=localStorage.getItem(NOTE_KEY)||'';noteInputEl.value=n;homeNoteEl.textContent=n||'आजची Note नाही.';
 v92SyncStatus();
 entriesEl.innerHTML=state.entries.length?state.entries.slice().reverse().map(e=>`<div class="entry"><div class="entrytext"><b>${e.order==='Family'?'👨‍👩‍👧‍👦 Family Order':esc(e.name)}</b> — ${money(e.total)} • ${esc(e.customer)}<br><span class="small">${esc(e.customerName||'')} ${e.customerMobile?'• '+esc(e.customerMobile):''} • ${esc(e.details||'')} • ${e.time}</span></div><button type="button" class="del" style="cursor:pointer;pointer-events:auto;position:relative;z-index:5" onclick="event.preventDefault();event.stopPropagation();del('${String(e.id)}');return false;">🗑️ ही Entry Delete करा</button></div>`).join(''):'<span class="small">Entry नाही.</span>';
 let ex=document.getElementById('expenseEntries');if(ex)ex.innerHTML=state.expenses.length?state.expenses.slice().reverse().map(x=>`<div class="entry"><div class="entrytext"><b>${money(x.amount)}</b><br><span class="small">${esc(x.date)} • ${esc(x.time)} • ${esc(x.purpose||'Purpose नाही')}</span></div><button class="del" onclick="deleteExpense('${String(x.id)}')">🗑️ Delete</button></div>`).join(''):'<span class="small">Expense entry नाही.</span>';
 let de=document.getElementById('deletedEntries');
if(de){
 const deleted=Array.isArray(state.deletedEntries)?state.deletedEntries:[];
 de.innerHTML=deleted.length
 ? `<div class="small" style="margin-bottom:6px">Deleted Sales Entries: ${deleted.length}</div>`+
   deleted.slice().reverse().map(x=>`<div class="entry">
     <div class="entrytext"><b>🧾 ${esc(x.name||'Entry')}</b> — ${money(x.total||0)}<br>
     <span class="small">${esc(x.date||'')} • ${esc(x.time||'')} • ${esc(x.details||'')}</span></div>
     <button type="button" class="btn green" onclick="restoreDeleted('${String(x.id)}')">↩️ Restore</button>
   </div>`).join('')
 : '<span class="small">Deleted entry नाही.</span>';
}
 renderDashboard();renderCustomers();renderMenuManager()
}
async function del(id){
 id=String(id);
 if(!Array.isArray(state.entries))state.entries=[];
 const i=state.entries.findIndex(e=>String(e.id)===id);
 if(i<0){toast('❌ Entry सापडली नाही');return}
 const e=state.entries[i];
 if(!confirm('⚠️ ही Entry Delete करायची आहे?\n\n'+(e.name||'Entry')+' • '+money(e.total)+'\n\nही Entry Recently Deleted मध्ये ठेवली जाईल आणि Restore करता येईल.')) return;
 state.entries.splice(i,1);
 if(!Array.isArray(state.deletedEntries))state.deletedEntries=[];
 e.deletedAt=date()+' '+time();
 e.deletedReason='User deleted';
 e.deletedCreditRecords=(state.creditLedger||[]).filter(c=>String(c.entryId)===id);
 state.creditLedger=(state.creditLedger||[]).filter(c=>String(c.entryId)!==id);
 state.deletedEntries.push(e);
 if(e.customer==='नवीन')state.newCustomers=Math.max(0,state.newCustomers-1);
 else if(e.customer==='जुना' || e.customer==='Repeat')state.repeatCustomers=Math.max(0,state.repeatCustomers-1);
 save(STATE_KEY,state);
 localStorage.setItem('PP_V142_ENTRIES_MIRROR',JSON.stringify(state.entries));
 renderAdmin();
 toast('✓ ENTRY DELETED • Recently Deleted मध्ये ठेवली');
 try{if(typeof v9Save==='function')await v9Save()}catch(err){}
 queueDriveSync(false);
}
function deleteExpense(id){id=String(id);let i=(state.expenses||[]).findIndex(x=>String(x.id)===id);if(i<0)return toast('❌ Expense सापडला नाही');let x=state.expenses[i];if(!confirm('हा Expense delete करायचा?\n\n'+money(x.amount)+' • '+(x.purpose||'Purpose नाही')))return;state.expenses.splice(i,1);state.expense=state.expenses.reduce((a,e)=>a+Number(e.amount||0),0);save(STATE_KEY,state);localStorage.setItem('PP_V142_EXPENSES_MIRROR',JSON.stringify(state.expenses));v92SaveEverything();renderAdmin();toast('✓ Expense deleted');queueDriveSync(false)}
function restoreDeleted(id){id=String(id);let i=(state.deletedEntries||[]).findIndex(e=>String(e.id)===id);if(i<0)return toast('❌ Deleted entry सापडली नाही');let e=state.deletedEntries[i];if(state.entries.some(x=>String(x.id)===id))return toast('Entry already exists');delete e.deletedAt;delete e.deletedReason;let deletedCredits=Array.isArray(e.deletedCreditRecords)?e.deletedCreditRecords:[];delete e.deletedCreditRecords;state.entries.push(e);state.deletedEntries.splice(i,1);if(e.customer==='नवीन')state.newCustomers++;else if(e.customer==='जुना'||e.customer==='Repeat')state.repeatCustomers++;if(deletedCredits.length){if(!Array.isArray(state.creditLedger))state.creditLedger=[];deletedCredits.forEach(c=>{if(!Array.isArray(c.payments))c.payments=[];state.creditLedger.push(c)})}else if(e.paymentMode==='Credit'){if(!Array.isArray(state.creditLedger))state.creditLedger=[];state.creditLedger.push({id:e.id,entryId:e.id,date:e.date,time:e.time,customerName:e.customerName,customerMobile:e.customerMobile,amount:e.total,paid:0,outstanding:e.total,status:'Outstanding',payments:[]})}save(STATE_KEY,state);localStorage.setItem('PP_V142_ENTRIES_MIRROR',JSON.stringify(state.entries));v92SaveEverything();renderAdmin();toast('✓ Entry restored');queueDriveSync(false)}
function exportXLSX(){toast('☁️ .xlsx file Google Drive sync मधून तयार/updated होते.');queueDriveSync(true)}
function exportCSV(){
 let rows=[['Date','Time','Day','Order Type','Item / Details','Quantity','Unit Price','Total Price','Customer Type','Customer Name','Mobile','Payment Mode','Credit Status']];
 state.entries.forEach(e=>rows.push([e.date,e.time,e.day,e.order,e.details||e.name,e.qty,e.price||'',e.total,e.customer,e.customerName||'',e.customerMobile||'',e.paymentMode||'Cash',e.creditStatus||'Paid']));
 let csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n'),blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download='PaniPuri_V13_Backup_'+new Date().toISOString().slice(0,10)+'.csv';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(u);toast('✓ BACKUP READY')
}
function newDay(){if(!confirm('आधी Backup केला आहे ना? Data reset करायचा आहे?'))return;state={entries:[],newCustomers:0,repeatCustomers:0,expense:0,expenses:[],creditLedger:[],deletedEntries:[]};save(STATE_KEY,state);v92SaveEverything();renderAdmin();toast('✓ NEW DAY STARTED');queueDriveSync(false)}

window.PPHandleBack=function(){
  if(!document.getElementById('adFull').classList.contains('hidden')){hideAdvertisement();return true;}
  const ids=['creditPayModal','creditDetailModal','creditQuickModal','otherModal','expensePadModal','paymentModal','customerModal','familyModal','addMenuModal','pinModal'];
  for(const id of ids){const el=document.getElementById(id);if(el&&!el.classList.contains('hidden')){el.classList.add('hidden');return true;}}
  if(!document.getElementById('adminPage').classList.contains('hidden')){backHome();return true;}
  return false;
};

v92Migrate();
clock();renderMainMenu();renderBill();v92SyncStatus();updateAdAdminStatus();resetIdleAd();


document.addEventListener('click',function(ev){
  const b=ev.target.closest && ev.target.closest('button.main.family');
  if(b){
    ev.preventDefault();
    ev.stopPropagation();
    if(typeof openFamily==='function')openFamily();
  }
},true);


const V9_DB='PaniPuriBusinessV9', V9_STORE='app';
function v9Open(){return new Promise((ok,no)=>{let r=indexedDB.open(V9_DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(V9_STORE))r.result.createObjectStore(V9_STORE)};r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}
async function v9Put(k,v){try{let d=await v9Open(),t=d.transaction(V9_STORE,'readwrite');t.objectStore(V9_STORE).put(v,k)}catch(e){}}
async function v9Save(){await v9Put('state',state);await v9Put('menu',menuItems);await v9Put('prices',prices);await v9Put('note',localStorage.getItem(NOTE_KEY)||'')}
async function v9Hydrate(){
 try{
   const localStateRaw=localStorage.getItem(STATE_KEY);
   const localMenuRaw=localStorage.getItem(MENU_KEY);
   const localPricesRaw=localStorage.getItem(PRICES_KEY);
   const hasLocalState=!!localStateRaw, hasLocalMenu=!!localMenuRaw, hasLocalPrices=!!localPricesRaw;
   let d=await v9Open(),g=k=>new Promise((ok,no)=>{
     let r=d.transaction(V9_STORE).objectStore(V9_STORE).get(k);
     r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)
   });
   let s=await g('state'),m=await g('menu'),p=await g('prices'),n=await g('note');
   if(!hasLocalState && s){state=s;save(STATE_KEY,state)}
   if(!hasLocalMenu && m){menuItems=m;save(MENU_KEY,menuItems)}
   if(!hasLocalPrices && p){prices=p;save(PRICES_KEY,prices)}
   if(!localStorage.getItem(NOTE_KEY) && n!==undefined)localStorage.setItem(NOTE_KEY,n||'');
   normalizeV142State();
   renderMainMenu();renderBill();
   if(!adminPage.classList.contains('hidden'))renderAdmin();
   if(typeof syncState!=='undefined')syncState.textContent='Local + IndexedDB सुरक्षित';
 }catch(e){
   normalizeV142State();
   renderMainMenu();renderBill();
   if(!adminPage.classList.contains('hidden'))renderAdmin();
 }
}
function downloadBackup(){let d={version:'V13',exportedAt:new Date().toISOString(),state,menuItems,prices,note:localStorage.getItem(NOTE_KEY)||''};let b=new Blob([JSON.stringify(d,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='PaniPuri_Business_V9_2_Backup_'+new Date().toISOString().slice(0,10)+'.json';a.click();toast('✓ FULL BACKUP READY')}
function restoreBackup(ev){let f=ev.target.files&&ev.target.files[0];if(!f)return;let r=new FileReader();r.onload=async()=>{try{let d=JSON.parse(r.result);if(!d.state||!Array.isArray(d.state.entries))throw 0;state=d.state;if(Array.isArray(d.menuItems))menuItems=d.menuItems;if(d.prices)prices=d.prices;localStorage.setItem(NOTE_KEY,d.note||'');save(STATE_KEY,state);save(MENU_KEY,menuItems);save(PRICES_KEY,prices);await v9Save();renderMainMenu();renderBill();if(!adminPage.classList.contains('hidden'))renderAdmin();toast('✓ BACKUP RESTORED')}catch(e){toast('❌ Backup file योग्य नाही')}ev.target.value=''};r.readAsText(f)}
v9Hydrate();
try{
 if(!localStorage.getItem('PP_V142_ENTRIES_MIRROR') && Array.isArray(state.entries) && state.entries.length) localStorage.setItem('PP_V142_ENTRIES_MIRROR',JSON.stringify(state.entries));
 if(!localStorage.getItem('PP_V142_EXPENSES_MIRROR') && Array.isArray(state.expenses) && state.expenses.length) localStorage.setItem('PP_V142_EXPENSES_MIRROR',JSON.stringify(state.expenses));
}catch(e){}
setTimeout(()=>{if(!Array.isArray(state.expenses))state.expenses=[];if(!Array.isArray(state.creditLedger))state.creditLedger=[];if(!Array.isArray(state.deletedEntries))state.deletedEntries=[];updateAdAdminStatus();resetIdleAd();},500);




// V14 Automatic Google Drive + Excel sync
let driveConnected=false, drivePending=0, driveSyncBusy=false;
function drivePayload(){
  return JSON.stringify({version:'V14',backupType:'Pani Puri Business Automatic Excel Sync',exportedAt:new Date().toISOString(),state,menuItems,prices,note:localStorage.getItem(NOTE_KEY)||''});
}
function setDriveUI(status,stateText,pending){
  const a=document.getElementById('driveStatus'),b=document.getElementById('driveSyncState'),c=document.getElementById('drivePending');
  if(a)a.textContent=status||''; if(b)b.textContent=stateText||'LOCAL'; if(c)c.textContent=String(pending??drivePending);
}
function connectGoogleDrive(){
  if(typeof AndroidDrive==='undefined'||!AndroidDrive.connect){toast('❌ V14 Android build आवश्यक आहे');return;}
  setDriveUI('Google Drive authorization सुरू आहे...','CONNECTING',drivePending); AndroidDrive.connect();
}
function syncGoogleDriveNow(){queueDriveSync(true)}
function queueDriveSync(manual=false){
  drivePending=1; setDriveUI(navigator.onLine?'Google Drive sync तयार...':'Internet नाही — data Local मध्ये सुरक्षित','PENDING',drivePending);
  if(!navigator.onLine){return}
  if(!driveConnected){setDriveUI('Google Drive Connect करा','LOCAL',drivePending);return}
  if(driveSyncBusy)return;
  if(typeof AndroidDrive==='undefined'||!AndroidDrive.sync){setDriveUI('Google Drive bridge उपलब्ध नाही','LOCAL',drivePending);return}
  driveSyncBusy=true; setDriveUI('Excel Google Drive ला sync होत आहे...','SYNCING',drivePending);
  try{AndroidDrive.sync(drivePayload())}catch(e){driveSyncBusy=false;setDriveUI('Sync error','PENDING',drivePending);if(manual)toast('❌ Sync सुरू झाला नाही: '+e.message)}
}
window.__driveConnectResult=function(raw){
 try{const r=typeof raw==='string'?JSON.parse(raw):raw;if(r&&r.ok){driveConnected=true;setDriveUI('Google Drive Connected ✓','CONNECTED',drivePending);toast('✓ Google Drive Connected');queueDriveSync(false)}else{setDriveUI('Google Drive connect झाले नाही','LOCAL',drivePending);toast('❌ Google Drive: '+(r?.message||'Authorization failed'))}}catch(e){setDriveUI('Connect result error','LOCAL',drivePending)}};
window.__driveStatusResult=function(raw){
 try{const r=typeof raw==='string'?JSON.parse(raw):raw;if(r&&r.ok&&r.message==='connected'){driveConnected=true;setDriveUI('Google Drive Connected ✓','CONNECTED',drivePending);if(navigator.onLine)queueDriveSync(false)}}catch(e){}
};
window.__driveSyncResult=function(raw){
 driveSyncBusy=false;
 try{const r=typeof raw==='string'?JSON.parse(raw):raw;if(r&&r.ok){drivePending=0;setDriveUI('Google Drive Excel Sync पूर्ण ✓','SYNCED',0);localStorage.setItem('V14_LAST_SYNC',new Date().toISOString());toast('✓ Google Drive Excel updated')}else{drivePending=1;setDriveUI('Sync pending — Internet/permission तपासा','PENDING',1)}}catch(e){drivePending=1;setDriveUI('Sync pending','PENDING',1)}
};
window.addEventListener('online',()=>{setDriveUI('Internet आले — automatic sync सुरू...','PENDING',drivePending);queueDriveSync(false)});
window.addEventListener('offline',()=>setDriveUI('Internet नाही — Local मध्ये सुरक्षित','OFFLINE',drivePending));
setInterval(()=>{if(driveConnected && navigator.onLine && !driveSyncBusy)queueDriveSync(false)},30000);
// Restore a simple status when admin opens.
try{if(typeof AndroidDrive!=='undefined'&&AndroidDrive.status)AndroidDrive.status()}catch(e){}
