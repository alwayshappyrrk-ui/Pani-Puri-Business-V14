Pani Puri Business V14.2 - Current Bill Save + Compact Credit Fix

Changes:
- Current Bill is persisted locally as a draft.
- Cash/Credit from Current Bill now reliably saves the sale to local state before clearing the bill.
- Save errors are shown instead of silently failing.
- Credit button in Current Bill is compact.
- Credit button in payment modal is compact and says Credit & Save.
- Other Amount remains a bill line item and has no Cash/Credit choice inside the Other Amount keypad.
