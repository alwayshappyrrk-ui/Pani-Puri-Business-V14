Pani Puri Business V13
Offline-first billing app with local storage, Google Drive backup/restore via Android document picker, Excel export, dashboard, customers, menu management, reminders and Admin PIN. Supabase email login is removed from the main app flow.

Google Drive note: Backup/Restore uses Android ACTION_CREATE_DOCUMENT / ACTION_OPEN_DOCUMENT. The app creates a complete JSON backup containing business state, menu, prices and note. In the Android file picker, choose Google Drive as the save/open location. No Google service credentials are embedded in the APK.
