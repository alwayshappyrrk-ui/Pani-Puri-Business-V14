package com.panipuri.business;

import android.app.Activity;
import android.content.Intent;
import android.webkit.ValueCallback;
import java.io.File;
import java.io.FileOutputStream;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.AuthorizationClient;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

import android.app.PendingIntent;
import android.content.IntentSender;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_AUTHORIZE = 8101;
    private static final int REQ_AD_MEDIA = 9201;
    private ValueCallback<Uri[]> pendingFileChooser;
    private final android.window.OnBackInvokedCallback backCallback = this::handleBackPressed;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private AuthorizationClient authClient;
    private String pendingSyncJson;
    private boolean pendingConnect;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                // Also support normal HTML file inputs if a future screen uses one.
                if(pendingFileChooser!=null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser=callback;
                try{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                    startActivityForResult(i,REQ_AD_MEDIA);
                    return true;
                }catch(Exception e){ pendingFileChooser=null; return false; }
            }
        });
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/admedia/", new WebViewAssetLoader.InternalStoragePathHandler(this, getFilesDir())).build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,String u){WebResourceResponse r=loader.shouldInterceptRequest(Uri.parse(u));return r!=null?r:super.shouldInterceptRequest(v,u);}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,android.webkit.WebResourceRequest q){WebResourceResponse r=loader.shouldInterceptRequest(q.getUrl());return r!=null?r:super.shouldInterceptRequest(v,q);}
        });
        webView.addJavascriptInterface(new AndroidXlsxBridge(), "AndroidXlsx");
        webView.addJavascriptInterface(new AndroidDriveBridge(), "AndroidDrive");
        webView.addJavascriptInterface(new AndroidMediaBridge(), "AndroidMedia");
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        setContentView(webView);
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,backCallback);
    }
    @Override @SuppressWarnings("deprecation") public void onBackPressed(){if(Build.VERSION.SDK_INT<33)handleBackPressed();}
    private void handleBackPressed(){if(webView==null){finish();return;}webView.evaluateJavascript("(window.PPHandleBack ? window.PPHandleBack() : false)",v->{if(!"true".equals(v))finish();});}
    @Override protected void onDestroy(){if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);io.shutdownNow();if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}

    public class AndroidDriveBridge {
        @JavascriptInterface public void connect(){ runOnUiThread(()->authorize(null,true)); }
        @JavascriptInterface public void sync(final String json){
            if(json==null || json.trim().isEmpty()) { callback("__driveSyncResult",false,"Data रिकामा आहे"); return; }
            runOnUiThread(()->authorize(json,false));
        }
        @JavascriptInterface public void status(){
            boolean c=getPreferences(0).getBoolean("drive_connected",false);
            callback("__driveStatusResult",true,c?"connected":"not_connected");
        }
    }

    public class AndroidMediaBridge {
        @JavascriptInterface public void pickAdvertisementMedia(){
            runOnUiThread(()->{
                try{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                    startActivityForResult(i,REQ_AD_MEDIA);
                }catch(Exception e){
                    callback("__adMediaResult",false,"File picker सुरू झाला नाही: "+errorText(e));
                }
            });
        }
        @JavascriptInterface public void removeAdvertisement(){
            try{
                deleteAdFiles("ad_image"); deleteAdFiles("ad_video");
                File meta=new File(getFilesDir(),"ad_media_meta.txt"); if(meta.exists()) meta.delete();
                getPreferences(0).edit().remove("ad_media_type").apply();
                callback("__adMediaResult",true,"removed");
            }catch(Exception e){callback("__adMediaResult",false,errorText(e));}
        }
    }

    private void authorize(String syncJson, boolean connectOnly){
        pendingSyncJson=syncJson; pendingConnect=connectOnly;
        try{
            authClient=Identity.getAuthorizationClient(this);
            List<Scope> scopes=Arrays.asList(new Scope("https://www.googleapis.com/auth/drive.file"));
            AuthorizationRequest req=AuthorizationRequest.builder().setRequestedScopes(scopes).build();
            authClient.authorize(req).addOnSuccessListener(result->{
                if(result.hasResolution()){
                    PendingIntent pi=result.getPendingIntent();
                    try{
                        startIntentSenderForResult(pi.getIntentSender(),REQ_AUTHORIZE,null,0,0,0,null);
                    }catch(IntentSender.SendIntentException e){
                        callback(connectOnly?"__driveConnectResult":"__driveSyncResult",
                                false,"Google authorization सुरू झाले नाही: "+errorText(e));
                    }
                }else handleAuthorization(result);
            }).addOnFailureListener(e->{callback(connectOnly?"__driveConnectResult":"__driveSyncResult",false,errorText(e));});
        }catch(Exception e){callback(connectOnly?"__driveConnectResult":"__driveSyncResult",false,errorText(e));}
    }

    private void handleAuthorization(AuthorizationResult result){
        String token=result.getAccessToken();
        if(token==null || token.isEmpty()){callback(pendingConnect?"__driveConnectResult":"__driveSyncResult",false,"Google access token मिळाला नाही");return;}
        getPreferences(0).edit().putBoolean("drive_connected",true).apply();
        if(pendingConnect){pendingConnect=false;callback("__driveConnectResult",true,"Google Drive Connected"); if(pendingSyncJson!=null){String j=pendingSyncJson;pendingSyncJson=null;syncWithToken(token,j);}}
        else {String j=pendingSyncJson;pendingSyncJson=null;syncWithToken(token,j);}
    }

    private void deleteAdFiles(String prefix){
        File[] fs=getFilesDir().listFiles();
        if(fs!=null) for(File f:fs) if(f.getName().startsWith(prefix)) f.delete();
    }
    private String mediaExtension(String mime,boolean video){
        String m=mime==null?"":mime.toLowerCase(Locale.US);
        if(video){ if(m.contains("webm"))return ".webm"; if(m.contains("3gp"))return ".3gp"; return ".mp4"; }
        if(m.contains("png"))return ".png"; if(m.contains("webp"))return ".webp"; if(m.contains("gif"))return ".gif"; return ".jpg";
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_AD_MEDIA){
            if(resultCode!=RESULT_OK || data==null){
                if(pendingFileChooser!=null){pendingFileChooser.onReceiveValue(null);pendingFileChooser=null;}
                callback("__adMediaResult",false,"Advertisement media निवडले नाही");
                return;
            }
            try{
                ArrayList<Uri> uris=new ArrayList<>();
                if(data.getClipData()!=null){
                    for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());
                }else if(data.getData()!=null){uris.add(data.getData());}
                if(uris.isEmpty())throw new Exception("Media निवडले नाही");

                deleteAdFiles("ad_image_"); deleteAdFiles("ad_video_");
                JSONArray items=new JSONArray();
                boolean hasVideo=false;
                int imageNo=0, videoNo=0;
                for(Uri uri:uris){
                    String mime=getContentResolver().getType(uri);
                    boolean video=mime!=null && mime.toLowerCase(Locale.US).startsWith("video/");
                    if(video) {
                        // Keep video support simple: first video is accepted; images can be multiple.
                        if(hasVideo) continue;
                        hasVideo=true;
                    }
                    String ext=mediaExtension(mime,video);
                    String prefix=video?"ad_video_":"ad_image_";
                    String name=prefix+(video?(videoNo++):(imageNo++))+ext;
                    File out=new File(getFilesDir(),name);
                    try(InputStream in=getContentResolver().openInputStream(uri); FileOutputStream fos=new FileOutputStream(out)){
                        if(in==null)throw new Exception("File वाचता आली नाही");
                        byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)fos.write(buf,0,n);
                    }
                    JSONObject one=new JSONObject();
                    one.put("type",video?"video":"image");
                    one.put("url","https://appassets.androidplatform.net/admedia/"+name);
                    one.put("mime",mime==null?(video?"video/mp4":"image/*"):mime);
                    one.put("duration",video?10:5);
                    items.put(one);
                }
                if(items.length()==0)throw new Exception("Valid image/video सापडले नाही");
                if(pendingFileChooser!=null){
                    pendingFileChooser.onReceiveValue(new Uri[]{Uri.parse(items.getJSONObject(0).getString("url"))});
                    pendingFileChooser=null;
                }
                JSONObject result=new JSONObject();
                result.put("ok",true);
                result.put("items",items);
                callback("__adMediaResult",true,result.toString());
            }catch(Exception e){
                if(pendingFileChooser!=null){pendingFileChooser.onReceiveValue(null);pendingFileChooser=null;}
                callback("__adMediaResult",false,"Advertisement media save error: "+errorText(e));
            }
            return;
        }
        if(requestCode!=REQ_AUTHORIZE) return;

        final String fn=pendingConnect?"__driveConnectResult":"__driveSyncResult";

        // Important: even when Android reports RESULT_CANCELED, ask
        // Google Identity to decode the returned Intent first.  Google
        // can place the real OAuth/API failure inside that Intent.
        try{
            if(data!=null){
                AuthorizationResult r=Identity.getAuthorizationClient(this)
                        .getAuthorizationResultFromIntent(data);

                if(r!=null){
                    String token=r.getAccessToken();
                    if(token!=null && !token.isEmpty()){
                        handleAuthorization(r);
                        return;
                    }

                    StringBuilder msg=new StringBuilder();
                    msg.append("Google OAuth did not return an access token");
                    msg.append(" | resultCode=").append(resultCode);
                    if(resultCode==RESULT_CANCELED) msg.append(" (RESULT_CANCELED)");
                    List<String> granted=r.getGrantedScopes();
                    if(granted!=null) msg.append(" | grantedScopes=").append(granted);
                    android.os.Bundle params=r.getTokenResponseParams();
                    if(params!=null) msg.append(" | responseKeys=").append(params.keySet());

                    msg.append(" | Package=com.panipuri.business");
                    msg.append(" | SHA-1=F4:96:33:10:EE:A1:3D:7D:0C:64:1E:07:48:3E:C0:A4:C2:C1:C4:23");
                    msg.append(" | Check Google Cloud Test User and Android OAuth client");
                    callback(fn,false,msg.toString());
                    return;
                }
            }

            StringBuilder msg=new StringBuilder();
            msg.append("Google OAuth returned no authorization result");
            msg.append(" | resultCode=").append(resultCode);
            if(resultCode==RESULT_CANCELED) msg.append(" (RESULT_CANCELED)");
            msg.append(" | intentData=").append(data==null?"null":"present");
            msg.append(" | Package=com.panipuri.business");
            msg.append(" | SHA-1=F4:96:33:10:EE:A1:3D:7D:0C:64:1E:07:48:3E:C0:A4:C2:C1:C4:23");
            callback(fn,false,msg.toString());

        }catch(Exception e){
            callback(fn,false,"Google OAuth decode error | resultCode="+resultCode+" | "+errorText(e));
        }
    }

    private void syncWithToken(final String token, final String json){
        io.execute(()->{
            try{
                JSONObject d=new JSONObject(json);
                String folderId=findOrCreateFolder(token,"Pani Puri Business");
                byte[] xlsx=buildXlsx(d);
                String fileName="Pani_Puri_Master_Sales.xlsx";
                String fileId=findFile(token,fileName,folderId);
                if(fileId==null) fileId=createFile(token,fileName,folderId,xlsx); else updateFile(token,fileId,xlsx);
                callback("__driveSyncResult",true,"Synced");
            }catch(Exception e){callback("__driveSyncResult",false,errorText(e));}
        });
    }

    private String findOrCreateFolder(String token,String name)throws Exception{
        String q="name='"+escapeQuery(name)+"' and mimeType='application/vnd.google-apps.folder' and trashed=false";
        JSONObject r=getJson(token,"https://www.googleapis.com/drive/v3/files?q="+URLEncoder.encode(q,"UTF-8")+"&spaces=drive&fields=files(id,name)&pageSize=10");
        JSONArray a=r.optJSONArray("files"); if(a!=null&&a.length()>0)return a.getJSONObject(0).getString("id");
        JSONObject body=new JSONObject().put("name",name).put("mimeType","application/vnd.google-apps.folder");
        JSONObject c=postJson(token,"https://www.googleapis.com/drive/v3/files?fields=id,name",body.toString());
        return c.getString("id");
    }
    private String findFile(String token,String name,String folderId)throws Exception{
        String q="name='"+escapeQuery(name)+"' and '"+folderId+"' in parents and trashed=false";
        JSONObject r=getJson(token,"https://www.googleapis.com/drive/v3/files?q="+URLEncoder.encode(q,"UTF-8")+"&spaces=drive&fields=files(id,name)&pageSize=10");
        JSONArray a=r.optJSONArray("files");return a!=null&&a.length()>0?a.getJSONObject(0).getString("id"):null;
    }
    private String createFile(String token,String name,String folderId,byte[] data)throws Exception{
        JSONObject body=new JSONObject().put("name",name).put("mimeType","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").put("parents",new JSONArray().put(folderId));
        JSONObject c=postJson(token,"https://www.googleapis.com/drive/v3/files?fields=id,name",body.toString());
        String id=c.getString("id"); updateFile(token,id,data); return id;
    }
    private void updateFile(String token,String id,byte[] data)throws Exception{
        URL u=new URL("https://www.googleapis.com/upload/drive/v3/files/"+URLEncoder.encode(id,"UTF-8")+"?uploadType=media");
        HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("PATCH");c.setDoOutput(true);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");c.setFixedLengthStreamingMode(data.length);try(OutputStream o=c.getOutputStream()){o.write(data);}readResponse(c);
    }
    private JSONObject getJson(String token,String url)throws Exception{return requestJson(token,"GET",url,null);}
    private JSONObject postJson(String token,String url,String body)throws Exception{return requestJson(token,"POST",url,body);}
    private JSONObject requestJson(String token,String method,String url,String body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");byte[] b=body.getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(b.length);try(OutputStream o=c.getOutputStream()){o.write(b);}}
        String s=readResponse(c);return new JSONObject(s);
    }
    private String readResponse(HttpURLConnection c)throws Exception{
        int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String s=readAll(in);if(code<200||code>=300)throw new Exception("Drive API HTTP "+code+": "+s);return s;
    }
    private String readAll(InputStream in)throws Exception{if(in==null)return "";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)b.write(buf,0,n);return b.toString("UTF-8");}
    private String escapeQuery(String s){return s.replace("'","\\'");}
    private String errorText(Throwable e){
        if(e instanceof ApiException){
            ApiException a=(ApiException)e;
            String m=a.getMessage();
            return "Google ApiException | statusCode="+a.getStatusCode()+" | "+(m==null?"":m);
        }
        String m=e.getMessage();
        return m==null?e.getClass().getSimpleName():m;
    }
    private void callback(String fn,boolean ok,String msg){runOnUiThread(()->{if(webView==null)return;try{JSONObject r=new JSONObject().put("ok",ok);if(msg!=null)r.put("message",msg);webView.evaluateJavascript("window."+fn+"("+JSONObject.quote(r.toString())+");",null);}catch(Exception ignored){}});}

    // Minimal XLSX writer: four useful sheets, generated locally so no spreadsheet service is needed.
    private byte[] buildXlsx(JSONObject root)throws Exception{
        JSONObject state=root.optJSONObject("state");
        JSONArray entries=state==null?new JSONArray():state.optJSONArray("entries"); if(entries==null)entries=new JSONArray();
        JSONArray credit=state==null?new JSONArray():state.optJSONArray("creditLedger"); if(credit==null)credit=new JSONArray();
        JSONArray expenses=state==null?new JSONArray():state.optJSONArray("expenses"); if(expenses==null)expenses=new JSONArray();
        JSONObject dailyFinance=state==null?new JSONObject():state.optJSONObject("dailyFinance"); if(dailyFinance==null)dailyFinance=new JSONObject();

        List<Sheet> sheets=new ArrayList<>();
        Sheet sales=new Sheet("Sales");
        sales.rows.add(row("Date","Time","Day","Order Type","Item / Details","Quantity","Unit Price","Total Price","Customer Type","Customer Name","Mobile","Payment Mode","Credit Status"));
        Map<String,Double> daySale=new LinkedHashMap<>(), itemQty=new LinkedHashMap<>(), itemSale=new LinkedHashMap<>();
        Map<String,Integer> dayOrders=new LinkedHashMap<>();
        Map<String,Customer> customers=new LinkedHashMap<>();

        for(int i=0;i<entries.length();i++){
            JSONObject e=entries.getJSONObject(i);
            double total=e.optDouble("total",0), unit=e.optDouble("price",0);
            sales.rows.add(row(e.optString("date"),e.optString("time"),e.optString("day"),e.optString("order"),e.optString("details",e.optString("name")),String.valueOf(e.optInt("qty")),String.valueOf(unit),String.valueOf(total),e.optString("customer"),e.optString("customerName"),e.optString("customerMobile"),e.optString("paymentMode","Cash"),e.optString("creditStatus","Paid")));
            String date=e.optString("localDate",e.optString("date"));
            daySale.put(date,daySale.getOrDefault(date,0.0)+total);
            dayOrders.put(date,dayOrders.getOrDefault(date,0)+1);
            String details=e.optString("details",e.optString("name"));
            for(String part:details.split(" \\| ")){
                int ix=part.lastIndexOf(" x ");
                if(ix>0){String n=part.substring(0,ix);int q=parseInt(part.substring(ix+3));itemQty.put(n,itemQty.getOrDefault(n,0.0)+q);itemSale.put(n,itemSale.getOrDefault(n,0.0)+q*unit);}
            }
            String cn=e.optString("customerName");
            if(!cn.isEmpty()){Customer c=customers.get(cn);if(c==null){c=new Customer();customers.put(cn,c);}c.orders++;c.total+=total;c.mobile=e.optString("customerMobile");c.last=e.optString("date");}
        }

        Map<String,Double> dayExpense=new LinkedHashMap<>();
        for(int i=0;i<expenses.length();i++){
            JSONObject e=expenses.getJSONObject(i); double a=e.optDouble("amount",0);
            String d=e.optString("isoDate",e.optString("date"));
            dayExpense.put(d,dayExpense.getOrDefault(d,0.0)+a);
        }

        // Daily report: Opening + Sale - Purchase - Expense = Closing; Profit/Loss = Sale - Purchase - Expense.
        Sheet ds=new Sheet("Daily Summary");
        ds.rows.add(row("Date","Opening Balance","Total Sale","Total Purchase","Total Expense","Closing Balance","Profit / Loss","Orders"));
        java.util.TreeSet<String> allDays=new java.util.TreeSet<>();
        allDays.addAll(daySale.keySet()); allDays.addAll(dayExpense.keySet());
        for(int i=0;i<dailyFinance.names().length();i++)allDays.add(dailyFinance.names().getString(i));
        Map<String,double[]> dayValues=new LinkedHashMap<>();
        for(String d:allDays){
            JSONObject f=dailyFinance.optJSONObject(d); double opening=f==null?0:f.optDouble("opening",0); double purchase=f==null?0:f.optDouble("purchase",0);
            double sale=daySale.getOrDefault(d,0.0), exp=dayExpense.getOrDefault(d,0.0), closing=opening+sale-purchase-exp, profit=sale-purchase-exp;
            dayValues.put(d,new double[]{opening,sale,purchase,exp,closing,profit});
            ds.rows.add(row(d,String.valueOf(opening),String.valueOf(sale),String.valueOf(purchase),String.valueOf(exp),String.valueOf(closing),String.valueOf(profit),String.valueOf(dayOrders.getOrDefault(d,0))));
        }

        // Weekly report: Monday-based weeks. Opening = first day's opening, Closing = last day's closing.
        Sheet ws=new Sheet("Weekly Summary");
        ws.rows.add(row("Week","Opening Balance","Total Sale","Total Purchase","Total Expense","Closing Balance","Profit / Loss","Orders"));
        Map<String,double[]> weeks=new LinkedHashMap<>();
        for(String d:allDays){
            String wk=weekKey(d); double[] v=dayValues.get(d); double[] a=weeks.get(wk);
            if(a==null){a=new double[]{v[0],0,0,0,v[4],0,0};weeks.put(wk,a);} 
            a[1]+=v[1];a[2]+=v[2];a[3]+=v[3];a[4]=v[4];a[5]+=v[5];a[6]+=dayOrders.getOrDefault(d,0);
        }
        for(Map.Entry<String,double[]> x:weeks.entrySet()){double[] v=x.getValue();ws.rows.add(row(x.getKey(),String.valueOf(v[0]),String.valueOf(v[1]),String.valueOf(v[2]),String.valueOf(v[3]),String.valueOf(v[4]),String.valueOf(v[5]),String.valueOf((int)v[6])));}

        // Monthly report.
        Sheet ms=new Sheet("Monthly Summary");
        ms.rows.add(row("Month","Opening Balance","Total Sale","Total Purchase","Total Expense","Closing Balance","Profit / Loss","Orders"));
        Map<String,double[]> months=new LinkedHashMap<>();
        for(String d:allDays){
            String mo=monthKey(d); double[] v=dayValues.get(d); double[] a=months.get(mo);
            if(a==null){a=new double[]{v[0],0,0,0,v[4],0,0};months.put(mo,a);} 
            a[1]+=v[1];a[2]+=v[2];a[3]+=v[3];a[4]=v[4];a[5]+=v[5];a[6]+=dayOrders.getOrDefault(d,0);
        }
        for(Map.Entry<String,double[]> x:months.entrySet()){double[] v=x.getValue();ms.rows.add(row(x.getKey(),String.valueOf(v[0]),String.valueOf(v[1]),String.valueOf(v[2]),String.valueOf(v[3]),String.valueOf(v[4]),String.valueOf(v[5]),String.valueOf((int)v[6])));}

        Sheet items=new Sheet("Items"); items.rows.add(row("Item","Quantity Sold","Sales")); for(String n:itemQty.keySet())items.rows.add(row(n,String.valueOf(itemQty.get(n)),String.valueOf(itemSale.getOrDefault(n,0.0))));
        Sheet cust=new Sheet("Customers"); cust.rows.add(row("Customer Name","Mobile","Orders","Total","Last Visit","Outstanding Credit"));
        Map<String,Double> outstanding=new LinkedHashMap<>(); for(int i=0;i<credit.length();i++){JSONObject c=credit.getJSONObject(i);String k=c.optString("customerMobile",c.optString("customerName"));outstanding.put(k,outstanding.getOrDefault(k,0.0)+c.optDouble("outstanding",0));}
        for(Map.Entry<String,Customer> x:customers.entrySet()){Customer c=x.getValue();cust.rows.add(row(x.getKey(),c.mobile,String.valueOf(c.orders),String.valueOf(c.total),c.last,String.valueOf(outstanding.getOrDefault(c.mobile.isEmpty()?x.getKey():c.mobile,0.0))));}
        Sheet cr=new Sheet("Credit"); cr.rows.add(row("Date","Time","Customer Name","Mobile","Amount","Paid","Outstanding","Status")); for(int i=0;i<credit.length();i++){JSONObject c=credit.getJSONObject(i);cr.rows.add(row(c.optString("date"),c.optString("time"),c.optString("customerName"),c.optString("customerMobile"),String.valueOf(c.optDouble("amount",0)),String.valueOf(c.optDouble("paid",0)),String.valueOf(c.optDouble("outstanding",0)),c.optString("status","Outstanding")));}
        Sheet ex=new Sheet("Expenses"); ex.rows.add(row("Date","Time","Day","Amount","Purpose")); double exTotal=0; for(int i=0;i<expenses.length();i++){JSONObject e=expenses.getJSONObject(i);double a=e.optDouble("amount",0);exTotal+=a;ex.rows.add(row(e.optString("date"),e.optString("time"),e.optString("day"),String.valueOf(a),e.optString("purpose")));} ex.rows.add(row("TOTAL","","",String.valueOf(exTotal),""));
        sheets.add(sales);sheets.add(ds);sheets.add(ws);sheets.add(ms);sheets.add(items);sheets.add(cust);sheets.add(cr);sheets.add(ex);
        return zipWorkbook(sheets);
    }
    private String weekKey(String d){
        try{String[] p=d.split("-");if(p.length==3){java.util.Calendar c=java.util.Calendar.getInstance();c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]),0,0,0);c.set(java.util.Calendar.MILLISECOND,0);int dow=c.get(java.util.Calendar.DAY_OF_WEEK);int delta=(dow==java.util.Calendar.SUNDAY?-6:java.util.Calendar.MONDAY-dow);c.add(java.util.Calendar.DATE,delta);return String.format(Locale.US,"%04d-%02d-%02d",c.get(java.util.Calendar.YEAR),c.get(java.util.Calendar.MONTH)+1,c.get(java.util.Calendar.DATE));}}catch(Exception ignored){}return d;
    }
    private String monthKey(String d){return d!=null&&d.length()>=7?d.substring(0,7):d;}
    private static class Sheet{String name;List<List<String>> rows=new ArrayList<>();Sheet(String n){name=n;}}
    private static class Customer{int orders;double total;String mobile="",last="";}
    private List<String> row(String...v){return Arrays.asList(v);}
    private int parseInt(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}
    private byte[] zipWorkbook(List<Sheet> sheets)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();ZipOutputStream z=new ZipOutputStream(out,StandardCharsets.UTF_8);
        put(z,"[Content_Types].xml",contentTypes(sheets.size()));put(z,"_rels/.rels",rels());put(z,"xl/workbook.xml",workbook(sheets));put(z,"xl/_rels/workbook.xml.rels",workbookRels(sheets.size()));
        for(int i=0;i<sheets.size();i++)put(z,"xl/worksheets/sheet"+(i+1)+".xml",sheetXml(sheets.get(i)));z.finish();z.close();return out.toByteArray();
    }
    private void put(ZipOutputStream z,String n,String s)throws Exception{z.putNextEntry(new ZipEntry(n));z.write(s.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private String contentTypes(int n){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");for(int i=1;i<=n;i++)b.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");return b.append("</Types>").toString();}
    private String rels(){return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";}
    private String workbook(List<Sheet>s){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");for(int i=0;i<s.size();i++)b.append("<sheet name=\"").append(xml(s.get(i).name)).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");return b.append("</sheets></workbook>").toString();}
    private String workbookRels(int n){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");for(int i=1;i<=n;i++)b.append("<Relationship Id=\"rId").append(i).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i).append(".xml\"/>");return b.append("</Relationships>").toString();}
    private String sheetXml(Sheet s){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");for(int r=0;r<s.rows.size();r++){b.append("<row r=\"").append(r+1).append("\">");for(int c=0;c<s.rows.get(r).size();c++){String v=s.rows.get(r).get(c);String ref=col(c)+(r+1);if(isNum(v)&&r>0)b.append("<c r=\"").append(ref).append("\"><v>").append(v).append("</v></c>");else b.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t>").append(xml(v)).append("</t></is></c>");}b.append("</row>");}return b.append("</sheetData></worksheet>").toString();}
    private String col(int n){StringBuilder s=new StringBuilder();n++;while(n>0){int r=(n-1)%26;s.insert(0,(char)('A'+r));n=(n-1)/26;}return s.toString();}
    private boolean isNum(String s){return s!=null&&s.matches("-?\\d+(\\.\\d+)?");}
    private String xml(String s){if(s==null)return "";return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}

    // Kept for compatibility with the existing app's local XLSX export bridge.
    public class AndroidXlsxBridge { @JavascriptInterface public void export(String json){ callback("__xlsxResult",false,"Native XLSX export is handled by Drive sync in V14"); } }
}
