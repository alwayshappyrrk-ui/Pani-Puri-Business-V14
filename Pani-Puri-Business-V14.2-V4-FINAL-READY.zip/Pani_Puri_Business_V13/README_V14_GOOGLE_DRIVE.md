# Pani Puri Business V14 – Automatic Google Drive Excel Sync

## What V14 does
- Keeps the app offline-first.
- Saves business data locally first.
- After a one-time Google Drive authorization, syncs the current data to:
  `Pani Puri Business/Pani_Puri_Master_Sales.xlsx`
- If the network is unavailable, data stays local and is marked Pending. When internet returns, the app retries automatically.
- The Excel workbook contains Sales, Daily Summary, Items, and Customers sheets.
- Uses Google Drive OAuth with the narrow `drive.file` scope. No Supabase login is used.

## One-time Google Cloud setup
1. Create/select a Google Cloud project.
2. Enable Google Drive API.
3. Configure Google Auth Platform / OAuth consent screen.
4. Create an **Android OAuth client** for package:
   `com.panipuri.business`
5. Add the SHA-1 certificate fingerprint for the APK you distribute. For GitHub Actions debug builds, obtain the debug keystore SHA-1 from the build environment or use a locally generated/release keystore and keep the same signing certificate for distributed APKs.
6. Add the `drive.file` scope.
7. Build/install V14 and tap **Connect Google Drive**.

## Important
Google's current Android guidance uses Google Identity Services `AuthorizationClient` for client-side API authorization. Access tokens are short-lived and are obtained again silently when the grant already exists. This app does not store a refresh token in the APK.

## GitHub Actions
Keep only ONE V14 source ZIP in the repository, named like:
`Pani_Puri_Business_V14*.zip`
The included `.github/workflows/main.yml` builds and uploads the APK artifact.
