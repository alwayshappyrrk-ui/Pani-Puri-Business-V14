package com.panipuri.business;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import androidx.webkit.WebViewAssetLoader;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.AuthorizationClient;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

import android.app.PendingIntent;
import android.content.IntentSender;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_AUTHORIZE = 8101;
    private final android.window.OnBackInvokedCallback backCallback = this::handleBackPressed;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private AuthorizationClient authClient;
    private String pendingSyncJson;
    private boolean pendingConnect;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,String u){WebResourceResponse r=loader.shouldInterceptRequest(Uri.parse(u));return r!=null?r:super.shouldInterceptRequest(v,u);}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,android.webkit.WebResourceRequest q){WebResourceResponse r=loader.shouldInterceptRequest(q.getUrl());return r!=null?r:super.shouldInterceptRequest(v,q);}
        });
        webView.addJavascriptInterface(new AndroidXlsxBridge(), "AndroidXlsx");
        webView.addJavascriptInterface(new AndroidDriveBridge(), "AndroidDrive");
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        setContentView(webView);
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,backCallback);
    }
    @Override @SuppressWarnings("deprecation") public void onBackPressed(){if(Build.VERSION.SDK_INT<33)handleBackPressed();}
    private void handleBackPressed(){if(webView==null){finish();return;}webView.evaluateJavascript("(window.PPHandleBack ? window.PPHandleBack() : false)",v->{if(!"true".equals(v))finish();});}
    @Override protected void onDestroy(){if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);io.shutdownNow();if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}

    public class AndroidDriveBridge {
        @JavascriptInterface public void connect(){ runOnUiThread(()->authorize(null,true)); }
        @JavascriptInterface public void sync(final String json){
            if(json==null || json.trim().isEmpty()) { callback("__driveSyncResult",false,"Data रिकामा आहे"); return; }
            runOnUiThread(()->authorize(json,false));
        }
        @JavascriptInterface public void status(){
            boolean c=getPreferences(0).getBoolean("drive_connected",false);
            callback("__driveStatusResult",true,c?"connected":"not_connected");
        }
    }

    private void authorize(String syncJson, boolean connectOnly){
        pendingSyncJson=syncJson; pendingConnect=connectOnly;
        try{
            authClient=Identity.getAuthorizationClient(this);
            List<Scope> scopes=Arrays.asList(new Scope("https://www.googleapis.com/auth/drive.file"));
            AuthorizationRequest req=AuthorizationRequest.builder().setRequestedScopes(scopes).build();
            authClient.authorize(req).addOnSuccessListener(result->{
                if(result.hasResolution()){
                    PendingIntent pi=result.getPendingIntent();
                    try{startIntentSenderForResult(pi.getIntentSender(),REQ_AUTHORIZE,null,0,0,0,null);}catch(IntentSender.SendIntentException e){callback("__driveConnectResult",false,"Google authorization सुरू झाले नाही");}
                }else handleAuthorization(result);
            }).addOnFailureListener(e->{callback(connectOnly?"__driveConnectResult":"__driveSyncResult",false,errorText(e));});
        }catch(Exception e){callback(connectOnly?"__driveConnectResult":"__driveSyncResult",false,errorText(e));}
    }

    private void handleAuthorization(AuthorizationResult result){
        String token=result.getAccessToken();
        if(token==null || token.isEmpty()){callback(pendingConnect?"__driveConnectResult":"__driveSyncResult",false,"Google access token मिळाला नाही");return;}
        getPreferences(0).edit().putBoolean("drive_connected",true).apply();
        if(pendingConnect){pendingConnect=false;callback("__driveConnectResult",true,"Google Drive Connected"); if(pendingSyncJson!=null){String j=pendingSyncJson;pendingSyncJson=null;syncWithToken(token,j);}}
        else {String j=pendingSyncJson;pendingSyncJson=null;syncWithToken(token,j);}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_AUTHORIZE){
            if(resultCode!=RESULT_OK){callback(pendingConnect?"__driveConnectResult":"__driveSyncResult",false,"Google Drive permission रद्द झाली");return;}
            try{AuthorizationResult r=Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);handleAuthorization(r);}catch(Exception e){callback(pendingConnect?"__driveConnectResult":"__driveSyncResult",false,errorText(e));}
        }
    }

    private void syncWithToken(final String token, final String json){
        io.execute(()->{
            try{
                JSONObject d=new JSONObject(json);
                String folderId=findOrCreateFolder(token,"Pani Puri Business");
                byte[] xlsx=buildXlsx(d);
                String fileName="Pani_Puri_Master_Sales.xlsx";
                String fileId=findFile(token,fileName,folderId);
                if(fileId==null) fileId=createFile(token,fileName,folderId,xlsx); else updateFile(token,fileId,xlsx);
                callback("__driveSyncResult",true,"Synced");
            }catch(Exception e){callback("__driveSyncResult",false,errorText(e));}
        });
    }

    private String findOrCreateFolder(String token,String name)throws Exception{
        String q="name='"+escapeQuery(name)+"' and mimeType='application/vnd.google-apps.folder' and trashed=false";
        JSONObject r=getJson(token,"https://www.googleapis.com/drive/v3/files?q="+URLEncoder.encode(q,"UTF-8")+"&spaces=drive&fields=files(id,name)&pageSize=10");
        JSONArray a=r.optJSONArray("files"); if(a!=null&&a.length()>0)return a.getJSONObject(0).getString("id");
        JSONObject body=new JSONObject().put("name",name).put("mimeType","application/vnd.google-apps.folder");
        JSONObject c=postJson(token,"https://www.googleapis.com/drive/v3/files?fields=id,name",body.toString());
        return c.getString("id");
    }
    private String findFile(String token,String name,String folderId)throws Exception{
        String q="name='"+escapeQuery(name)+"' and '"+folderId+"' in parents and trashed=false";
        JSONObject r=getJson(token,"https://www.googleapis.com/drive/v3/files?q="+URLEncoder.encode(q,"UTF-8")+"&spaces=drive&fields=files(id,name)&pageSize=10");
        JSONArray a=r.optJSONArray("files");return a!=null&&a.length()>0?a.getJSONObject(0).getString("id"):null;
    }
    private String createFile(String token,String name,String folderId,byte[] data)throws Exception{
        JSONObject body=new JSONObject().put("name",name).put("mimeType","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").put("parents",new JSONArray().put(folderId));
        JSONObject c=postJson(token,"https://www.googleapis.com/drive/v3/files?fields=id,name",body.toString());
        String id=c.getString("id"); updateFile(token,id,data); return id;
    }
    private void updateFile(String token,String id,byte[] data)throws Exception{
        URL u=new URL("https://www.googleapis.com/upload/drive/v3/files/"+URLEncoder.encode(id,"UTF-8")+"?uploadType=media");
        HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("PATCH");c.setDoOutput(true);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");c.setFixedLengthStreamingMode(data.length);try(OutputStream o=c.getOutputStream()){o.write(data);}readResponse(c);
    }
    private JSONObject getJson(String token,String url)throws Exception{return requestJson(token,"GET",url,null);}
    private JSONObject postJson(String token,String url,String body)throws Exception{return requestJson(token,"POST",url,body);}
    private JSONObject requestJson(String token,String method,String url,String body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");byte[] b=body.getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(b.length);try(OutputStream o=c.getOutputStream()){o.write(b);}}
        String s=readResponse(c);return new JSONObject(s);
    }
    private String readResponse(HttpURLConnection c)throws Exception{
        int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String s=readAll(in);if(code<200||code>=300)throw new Exception("Drive API HTTP "+code+": "+s);return s;
    }
    private String readAll(InputStream in)throws Exception{if(in==null)return "";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)b.write(buf,0,n);return b.toString("UTF-8");}
    private String escapeQuery(String s){return s.replace("'","\\'");}
    private String errorText(Exception e){String m=e.getMessage();return m==null?e.getClass().getSimpleName():m;}
    private void callback(String fn,boolean ok,String msg){runOnUiThread(()->{if(webView==null)return;try{JSONObject r=new JSONObject().put("ok",ok);if(msg!=null)r.put("message",msg);webView.evaluateJavascript("window."+fn+"("+JSONObject.quote(r.toString())+");",null);}catch(Exception ignored){}});}

    // Minimal XLSX writer: four useful sheets, generated locally so no spreadsheet service is needed.
    private byte[] buildXlsx(JSONObject root)throws Exception{
        JSONObject state=root.optJSONObject("state"); JSONArray entries=state==null?new JSONArray():state.optJSONArray("entries"); if(entries==null)entries=new JSONArray();
        List<Sheet> sheets=new ArrayList<>();
        Sheet sales=new Sheet("Sales");sales.rows.add(row("Date","Time","Day","Order Type","Item / Details","Quantity","Unit Price","Total Price","Customer Type","Customer Name","Mobile"));
        Map<String,Double> daySale=new LinkedHashMap<>(), itemQty=new LinkedHashMap<>(), itemSale=new LinkedHashMap<>(); Map<String,Customer> customers=new LinkedHashMap<>();
        for(int i=0;i<entries.length();i++){JSONObject e=entries.getJSONObject(i);sales.rows.add(row(e.optString("date"),e.optString("time"),e.optString("day"),e.optString("order"),e.optString("details",e.optString("name")),String.valueOf(e.optInt("qty")),String.valueOf(e.optDouble("price",0)),String.valueOf(e.optDouble("total",0)),e.optString("customer"),e.optString("customerName"),e.optString("customerMobile")));
            String date=e.optString("localDate",e.optString("date"));double total=e.optDouble("total",0);daySale.put(date,daySale.getOrDefault(date,0.0)+total);
            String details=e.optString("details",e.optString("name"));for(String part:details.split(" \\| ")){int ix=part.lastIndexOf(" x ");if(ix>0){String n=part.substring(0,ix);int q=parseInt(part.substring(ix+3));itemQty.put(n,itemQty.getOrDefault(n,0.0)+q);itemSale.put(n,itemSale.getOrDefault(n,0.0)+q*e.optDouble("price",0));}}
            String cn=e.optString("customerName");if(!cn.isEmpty()){Customer c=customers.get(cn);if(c==null){c=new Customer();customers.put(cn,c);}c.orders++;c.total+=total;c.mobile=e.optString("customerMobile");c.last=date;}
        }
        Sheet ds=new Sheet("Daily Summary");ds.rows.add(row("Date","Sales","Orders","Average Bill"));for(String d:daySale.keySet()){int n=0;for(int i=0;i<entries.length();i++)if(d.equals(entries.getJSONObject(i).optString("localDate",entries.getJSONObject(i).optString("date"))))n++;double s=daySale.get(d);ds.rows.add(row(d,String.valueOf(s),String.valueOf(n),String.valueOf(n==0?0:s/n)));}
        Sheet items=new Sheet("Items");items.rows.add(row("Item","Quantity Sold","Sales"));for(String n:itemQty.keySet())items.rows.add(row(n,String.valueOf(itemQty.get(n)),String.valueOf(itemSale.getOrDefault(n,0.0))));
        Sheet cust=new Sheet("Customers");cust.rows.add(row("Customer Name","Mobile","Orders","Total","Last Visit"));for(Map.Entry<String,Customer> x:customers.entrySet()){Customer c=x.getValue();cust.rows.add(row(x.getKey(),c.mobile,String.valueOf(c.orders),String.valueOf(c.total),c.last));}
        sheets.add(sales);sheets.add(ds);sheets.add(items);sheets.add(cust);
        return zipWorkbook(sheets);
    }
    private static class Sheet{String name;List<List<String>> rows=new ArrayList<>();Sheet(String n){name=n;}}
    private static class Customer{int orders;double total;String mobile="",last="";}
    private List<String> row(String...v){return Arrays.asList(v);}
    private int parseInt(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}
    private byte[] zipWorkbook(List<Sheet> sheets)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();ZipOutputStream z=new ZipOutputStream(out,StandardCharsets.UTF_8);
        put(z,"[Content_Types].xml",contentTypes(sheets.size()));put(z,"_rels/.rels",rels());put(z,"xl/workbook.xml",workbook(sheets));put(z,"xl/_rels/workbook.xml.rels",workbookRels(sheets.size()));
        for(int i=0;i<sheets.size();i++)put(z,"xl/worksheets/sheet"+(i+1)+".xml",sheetXml(sheets.get(i)));z.finish();z.close();return out.toByteArray();
    }
    private void put(ZipOutputStream z,String n,String s)throws Exception{z.putNextEntry(new ZipEntry(n));z.write(s.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private String contentTypes(int n){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");for(int i=1;i<=n;i++)b.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");return b.append("</Types>").toString();}
    private String rels(){return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";}
    private String workbook(List<Sheet>s){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");for(int i=0;i<s.size();i++)b.append("<sheet name=\"").append(xml(s.get(i).name)).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");return b.append("</sheets></workbook>").toString();}
    private String workbookRels(int n){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");for(int i=1;i<=n;i++)b.append("<Relationship Id=\"rId").append(i).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i).append(".xml\"/>");return b.append("</Relationships>").toString();}
    private String sheetXml(Sheet s){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");for(int r=0;r<s.rows.size();r++){b.append("<row r=\"").append(r+1).append("\">");for(int c=0;c<s.rows.get(r).size();c++){String v=s.rows.get(r).get(c);String ref=col(c)+(r+1);if(isNum(v)&&r>0)b.append("<c r=\"").append(ref).append("\"><v>").append(v).append("</v></c>");else b.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t>").append(xml(v)).append("</t></is></c>");}b.append("</row>");}return b.append("</sheetData></worksheet>").toString();}
    private String col(int n){StringBuilder s=new StringBuilder();n++;while(n>0){int r=(n-1)%26;s.insert(0,(char)('A'+r));n=(n-1)/26;}return s.toString();}
    private boolean isNum(String s){return s!=null&&s.matches("-?\\d+(\\.\\d+)?");}
    private String xml(String s){if(s==null)return "";return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}

    // Kept for compatibility with the existing app's local XLSX export bridge.
    public class AndroidXlsxBridge { @JavascriptInterface public void export(String json){ callback("__xlsxResult",false,"Native XLSX export is handled by Drive sync in V14"); } }
}
