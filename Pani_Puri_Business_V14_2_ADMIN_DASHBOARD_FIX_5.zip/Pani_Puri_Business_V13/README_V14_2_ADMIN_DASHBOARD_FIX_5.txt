Pani Puri Business V14.2 - Admin Dashboard / Menu / Expense / Entry Fix

This build preserves Credit, Current Bill, Family Order, Google Drive, advertisement and other existing features.

Fixed:
1. Menu Management:
   - Restores the default menu if the stored menu is empty/corrupt.
   - Preserves existing custom menu items.
   - Keeps editable Price field + Save Price for every menu item.
   - Price changes are saved to local storage and reflected on the main screen.

2. Admin dashboard:
   - Total Sale, Orders and Average Bill are calculated from the live saved entry store.
   - Repeat % is calculated from actual saved customer entries instead of stale counters.

3. Expenses:
   - Expense entries are stored in state + dedicated local mirror.
   - Admin restores the live expense mirror before rendering.
   - Total Expense and Net refresh immediately after saving.
   - Expense entries remain visible for delete.

4. Entries / Recently Deleted:
   - Admin restores the live sales mirror before rendering.
   - Deleted entries are stored in a dedicated deleted-entry mirror.
   - Delete -> Recently Deleted -> Restore persists across refresh/reopen.

No intentional changes to Credit, Current Bill, Family Order, Google Drive or advertisement behavior.
