Pani Puri Business V14.2 Feature Fix

Changes in this build:
1. Other Amount purpose is shown inside the current bill before completion.
2. Main screen has a Quick Credit button showing total outstanding amount.
3. Credit Quick View groups customers by name/mobile and shows outstanding total.
4. More opens customer-wise credit history: sale date/time, amount taken, amount paid, remaining, and payment history.
5. Partial payments are supported through a large keypad; payment date/time is recorded.
6. Admin Credit panel shows live customer credit entries and payment controls.
7. Admin Expenses panel shows every expense entry immediately with amount, date, time and purpose.
8. Sales entries use soft delete: deleted entries remain under Recently Deleted and can be restored.
9. Deleting a credit sale also removes its active credit ledger entry; restoring restores the saved credit ledger/payment history.
10. Advertisement picker supports multiple images. Each image has an individual display timer (seconds, 1-300).
11. Advertisement images slide full-screen automatically after 10 seconds of main-screen idle time.
12. Existing video advertisement support is retained; video plays full-screen, muted and loops.
13. Back navigation closes advertisement/modals/admin screens before exiting the app.
14. Google Drive OAuth FIX V2 code is preserved; Drive sync is not changed by this feature fix.


V14.2 Credit + Expense Fix
15. LocalStorage is now authoritative; stale IndexedDB data cannot overwrite newer local data on app start.
16. Credit remaining is recalculated as Total Credit - Total Paid and partial payments update Main/Admin balances.
17. Expenses can be deleted and restored from Recently Deleted Entries.
18. CSV Backup now includes sales, expenses and credit payment records.
