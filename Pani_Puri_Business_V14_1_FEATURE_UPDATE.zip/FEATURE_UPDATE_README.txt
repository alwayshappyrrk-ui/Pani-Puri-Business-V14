Pani Puri Business V14.1 - Feature Update

Includes:
1. Other Amount button below menu. Amount uses a large custom numeric keypad; optional purpose/reason.
2. Other Amount becomes part of the current bill and uses the same customer + Cash/Credit flow.
3. Cash / Credit payment choice after customer details for Single and Family orders.
4. Credit entries are stored with paymentMode=Credit and creditStatus=Unpaid.
5. Main screen: Udhaari Quick View with customer-wise outstanding and Mark Paid.
6. Main screen: Quick Expense with large custom numeric keypad and optional purpose.
7. Admin expense history, total expense and profit.
8. Google Drive XLSX Sales sheet now includes Payment Mode and Credit Status.
9. Added Credit and Expenses sheets to the Drive workbook.
10. Idle Menu Card / Advertisement: after 10 seconds without an entry, an automatic menu card appears; optional ad text can be configured in Admin.
11. Android swipe/predictive-back fix: modals close first, Admin returns to Entry, active bill is protected from accidental app close.
12. Preserves Google Drive OAuth FIX V2 and drive.file scope.
13. Package: com.panipuri.business
14. Version: 14.1 (versionCode 141)

OAuth Android certificate SHA-1 for the debug APK build remains:
F4:96:33:10:EE:A1:3D:7D:0C:64:1E:07:48:3E:C0:A4:C2:C1:C4:23
