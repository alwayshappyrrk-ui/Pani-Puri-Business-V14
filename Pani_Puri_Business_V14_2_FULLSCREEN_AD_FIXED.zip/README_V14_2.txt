Pani Puri Business V14.2
========================
Base: V14 OAuth FIX V2
Package: com.panipuri.business
Version: 14.2 (versionCode 142)

Features added:
- Full-screen idle Advertisement: image or video
- Admin media picker using Android file picker
- Image/video stored in app internal storage
- 10-second idle trigger on Main Screen
- Video autoplay, muted, loop, playsinline
- Tap/Back closes advertisement
- Other Amount with large keypad and optional purpose
- Cash / Credit payment flow after customer selection
- Credit ledger with customer-wise outstanding and Paid action
- Quick Expense with large keypad and optional purpose
- Expenses included in Drive Excel
- Sales Excel includes Payment Mode and Credit Status
- Excel adds Credit and Expenses sheets
- Android Back / swipe-back navigation handling for modals, admin and full-screen ad
- Keeps Google Drive OAuth FIX V2 and drive.file scope

Important:
- Google Cloud Android OAuth client should remain:
  Package: com.panipuri.business
  SHA-1: F4:96:33:10:EE:A1:3D:7D:0C:64:1E:07:48:3E:C0:A4:C2:C1:C4:23
- Advertisement media is local to the device and is NOT uploaded to the Excel file.
- The V14.2 workflow builds a debug APK. After installation, reconnect Google Drive if Android has cleared the previous authorization state.
