Pani Puri Business V14 - Google Drive OAuth FIX V2

This version is based on the supplied V14 source and the V1 diagnostic build.

V2 change:
- When Android returns RESULT_CANCELED, the app no longer immediately labels it as a user cancellation.
- It first passes the returned Intent to Google Identity's getAuthorizationResultFromIntent().
- If Google embeds an ApiException/status or authorization response information, that information is surfaced.
- If an access token is returned, the normal Drive sync flow continues.
- Diagnostic output includes resultCode, granted scopes/response keys where available, package and configured SHA-1.
- No Drive scope was broadened. The app continues to request:
  https://www.googleapis.com/auth/drive.file

This is intended to identify the exact OAuth failure before making any more Google Cloud changes.
