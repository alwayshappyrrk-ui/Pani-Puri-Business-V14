Pani Puri Business V14.2 – Full-Screen Image/Video Advertisement Update

New:
- Admin > Full-Screen Advertisement
- Pick Image or Video from Android device
- Saved media persists on device using IndexedDB
- After 10 seconds idle on the main entry screen, saved media opens full-screen
- Images use full screen with object-fit contain
- Videos autoplay muted, loop and play full-screen; Android autoplay restrictions may require first user interaction on some devices
- Optional advertisement text can be shown at the bottom
- Touch/X closes the advertisement and returns to entry screen
- If no media is saved, no idle advertisement is shown
- Existing V14.1 sales, credit, expense, Google Drive and back-swipe functionality retained
- Android WebView file chooser added for image/video selection

Note: Advertisement media is stored locally on the device. It is not placed inside the Excel workbook.
